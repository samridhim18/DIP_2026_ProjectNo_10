#!/usr/bin/env python3
"""
ECE501 Digital Image Processing Project (Group 10)
Brain MRI Tumor Segmentation and Quantitative Analysis Using Classical Image Processing
Ahmedabad University

Master Unified CLI Runner:
Provides a command-line interface to execute individual stages (1 to 5),
run custom patient/slice inferences, benchmark multi-patient cohorts,
generate publication figures, and produce LaTeX macros and tables.

Usage Examples:
    python main.py --stage 1
    python main.py --stage 2
    python main.py --stage 3
    python main.py --stage 4
    python main.py --stage 5
    python main.py --stage all
    python main.py --patient BraTS20_Training_001 --slice 67 --method kmeans3
    python main.py --evaluate-benchmark
    python main.py --extended-results
    python main.py --make-figures
    python main.py --generate-latex
"""

import os
import sys
import argparse
import numpy as np

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

from src.pipeline import run_pipeline, load_config
from src.utils import ensure_dir


def run_stage_1():
    print("\n" + "=" * 70)
    print(" Running Stage 1: Dataset Inspection, Normalization & Slicing")
    print("=" * 70)
    import subprocess
    # Run stage 1 logic via loader/preprocessing
    from src.loader import load_nifti_volume, get_volume_info
    from src.preprocessing import clip_percentiles, normalize_min_max, extract_axial_slice, find_best_slice
    from src.visualization import plot_mri_and_mask
    from src.utils import print_volume_summary

    flair_path = os.path.join(PROJECT_ROOT, "BraTS20_Training_001_flair.nii")
    seg_path = os.path.join(PROJECT_ROOT, "BraTS20_Training_001_seg.nii")
    output_dir = ensure_dir(os.path.join(PROJECT_ROOT, "outputs"))

    print("[Stage 1] Loading NIfTI volumes...")
    flair_vol, flair_nii = load_nifti_volume(flair_path)
    seg_vol, seg_nii = load_nifti_volume(seg_path)

    flair_info = get_volume_info(flair_vol, flair_nii, flair_path, is_mask=False)
    seg_info = get_volume_info(seg_vol, seg_nii, seg_path, is_mask=True)
    print_volume_summary("FLAIR MRI", flair_info)
    print_volume_summary("Ground-Truth Mask", seg_info)

    peak_slice_idx, peak_tumor_voxels = find_best_slice(seg_vol)
    print(f"[Stage 1] Peak Tumor Slice: {peak_slice_idx} (Tumor Voxels: {peak_tumor_voxels:,})")

    norm_slice = normalize_min_max(clip_percentiles(extract_axial_slice(flair_vol, peak_slice_idx), 0.5, 99.5))
    seg_slice = extract_axial_slice(seg_vol, peak_slice_idx)

    save_path = os.path.join(output_dir, f"flair_seg_overlay_peak_slice_{peak_slice_idx}.png")
    plot_mri_and_mask(norm_slice, seg_slice, peak_slice_idx, "Stage 1 Slice Inspection", alpha=0.5, save_path=save_path)
    print(f"[Stage 1] Saved overlay visualization to {save_path}")


def run_stage_2():
    print("\n" + "=" * 70)
    print(" Running Stage 2: Filtering, Contrast Enhancement & Metrics")
    print("=" * 70)
    import stage2_preprocessing
    stage2_preprocessing.main()


def run_stage_3():
    print("\n" + "=" * 70)
    print(" Running Stage 3: Intracranial Brain Mask Extraction")
    print("=" * 70)
    import stage3_skull_stripping
    stage3_skull_stripping.main()


def run_stage_4():
    print("\n" + "=" * 70)
    print(" Running Stage 4: Baseline Otsu Brain ROI Segmentation")
    print("=" * 70)
    import stage4_baseline_segmentation
    stage4_baseline_segmentation.main()


def run_stage_5_slice(patient_id="BraTS20_Training_001", slice_idx=67):
    print("\n" + "=" * 70)
    print(f" Running Stage 5: Method Comparison on {patient_id} Slice {slice_idx}")
    print("=" * 70)
    from src.segmentation_methods import (
        segment_global_otsu,
        segment_multi_otsu,
        segment_adaptive_local,
        segment_kmeans
    )
    from src.tumor_segmentation import morphological_tumor_cleanup
    from src.metrics import compute_all_metrics

    cfg = load_config()
    res = run_pipeline(patient_id, slice_idx, "flair", cfg)
    prep = res["preprocessed_slice"]
    bmask = res["brain_mask"]
    gt = res["gt_mask"]

    methods = {
        "Global Otsu": segment_global_otsu(prep, bmask),
        "Multi-Otsu (3 Classes)": segment_multi_otsu(prep, bmask, classes=3),
        "Adaptive Local": segment_adaptive_local(prep, bmask, block_size=15, offset=-0.02),
        "K-Means (K=2)": segment_kmeans(prep, bmask, k=2, random_state=42),
        "K-Means (K=3)": segment_kmeans(prep, bmask, k=3, random_state=42),
        "K-Means (K=4)": segment_kmeans(prep, bmask, k=4, random_state=42),
    }

    print(f"\n{'Method':<25} | {'Dice':<8} | {'IoU':<8} | {'Precision':<10} | {'Recall':<8}")
    print("-" * 70)
    for name, cand in methods.items():
        pred, _, _ = morphological_tumor_cleanup(cand, disk_r_open=2, disk_r_close=2, min_size=50)
        m = compute_all_metrics(pred, gt)
        print(f"{name:<25} | {m['dice']:<8.4f} | {m['iou']:<8.4f} | {m['precision']:<10.4f} | {m['recall']:<8.4f}")


def run_custom_segmentation(patient_id, slice_idx, modality, method_name):
    print("\n" + "=" * 70)
    print(f" Custom Inference: {patient_id} | Slice {slice_idx} | {modality.upper()} | Method: {method_name}")
    print("=" * 70)
    from src.segmentation_methods import (
        segment_global_otsu,
        segment_multi_otsu,
        segment_adaptive_local,
        segment_kmeans
    )
    from src.tumor_segmentation import morphological_tumor_cleanup
    from src.metrics import compute_all_metrics

    cfg = load_config()
    res = run_pipeline(patient_id, slice_idx, modality, cfg)
    prep = res["preprocessed_slice"]
    bmask = res["brain_mask"]
    gt = res["gt_mask"]

    m_clean = method_name.lower().replace("-", "").replace("_", "")
    if m_clean in ["otsu", "globalotsu"]:
        cand = segment_global_otsu(prep, bmask)
    elif m_clean in ["multiotsu", "motsu"]:
        cand = segment_multi_otsu(prep, bmask, classes=3)
    elif m_clean in ["adaptive", "local"]:
        cand = segment_adaptive_local(prep, bmask, block_size=15, offset=-0.02)
    elif m_clean in ["kmeans2", "k2"]:
        cand = segment_kmeans(prep, bmask, k=2, random_state=42)
    elif m_clean in ["kmeans3", "k3", "proposed", "selected"]:
        cand = segment_kmeans(prep, bmask, k=3, random_state=42)
    elif m_clean in ["kmeans4", "k4"]:
        cand = segment_kmeans(prep, bmask, k=4, random_state=42)
    else:
        raise ValueError(f"Unknown segmentation method: {method_name}")

    pred, _, info = morphological_tumor_cleanup(cand, disk_r_open=2, disk_r_close=2, min_size=50)
    m = compute_all_metrics(pred, gt)

    print(f" Predicted Tumor Pixels: {m['pred_area_px']:,}")
    print(f" Ground-Truth Pixels   : {m['gt_area_px']:,}")
    print(f" Dice Similarity (DSC) : {m['dice']:.4f}")
    print(f" Jaccard Index (IoU)   : {m['iou']:.4f}")
    print(f" Precision (PPV)       : {m['precision']:.4f}")
    print(f" Recall (Sensitivity)  : {m['recall']:.4f}")


def main():
    parser = argparse.ArgumentParser(
        description="ECE501 Digital Image Processing Project (Group 10) - Master CLI Runner"
    )
    parser.add_argument(
        "--stage",
        choices=["1", "2", "3", "4", "5", "all"],
        help="Execute pipeline stage (1: Loader, 2: Preproc, 3: Brain Mask, 4: Baseline Otsu, 5: Methods, all: End-to-End)"
    )
    parser.add_argument("--patient", type=str, default="BraTS20_Training_001", help="Patient ID")
    parser.add_argument("--slice", type=int, default=67, help="Axial slice index (0-154)")
    parser.add_argument("--modality", type=str, default="flair", choices=["flair", "t1", "t1ce", "t2"], help="MRI modality")
    parser.add_argument("--method", type=str, default="kmeans3", help="Segmentation method (otsu, multiotsu, adaptive, kmeans2, kmeans3, kmeans4)")
    parser.add_argument("--segment", action="store_true", help="Run custom segmentation inference using given patient, slice, and method")
    parser.add_argument("--evaluate-benchmark", action="store_true", help="Run full 20-patient / 200-slice DEV & TEST benchmark")
    parser.add_argument("--extended-results", action="store_true", help="Run extended experiments (failure analysis, modality, morphology, robustness)")
    parser.add_argument("--make-figures", action="store_true", help="Generate all 6 publication figures at 300 dpi with white backgrounds")
    parser.add_argument("--generate-latex", action="store_true", help="Generate numbers.tex and LaTeX table files from results CSVs")

    args = parser.parse_args()

    # If no flags provided, print help and run stage all by default
    if len(sys.argv) == 1:
        parser.print_help()
        print("\n[Default Execution] Running all stages (1 to 5) for baseline patient...")
        run_stage_1()
        run_stage_2()
        run_stage_3()
        run_stage_4()
        run_stage_5_slice("BraTS20_Training_001", 67)
        return

    if args.segment:
        run_custom_segmentation(args.patient, args.slice, args.modality, args.method)
        return

    if args.stage:
        if args.stage == "1":
            run_stage_1()
        elif args.stage == "2":
            run_stage_2()
        elif args.stage == "3":
            run_stage_3()
        elif args.stage == "4":
            run_stage_4()
        elif args.stage == "5":
            run_stage_5_slice(args.patient, args.slice)
        elif args.stage == "all":
            run_stage_1()
            run_stage_2()
            run_stage_3()
            run_stage_4()
            run_stage_5_slice(args.patient, args.slice)

    if args.evaluate_benchmark:
        print("\n[Master CLI] Running 20-patient / 200-slice Stage 5 benchmark...")
        import run_stage5_evaluation
        run_stage5_evaluation.main()

    if args.extended_results:
        print("\n[Master CLI] Running extended experiments (Failure, Modality, Morphology, Robustness)...")
        from src import compute_extended_results
        compute_extended_results.main()

    if args.make_figures:
        print("\n[Master CLI] Generating 300 dpi publication figures...")
        from src import make_paper_figures
        make_paper_figures.main()

    if args.generate_latex:
        print("\n[Master CLI] Generating LaTeX numbers.tex and table snippets...")
        from src import generate_latex_numbers
        generate_latex_numbers.main()


if __name__ == "__main__":
    main()
