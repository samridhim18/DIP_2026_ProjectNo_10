"""
test_pipeline.py
Unit and integration tests for the Classical DIP Tumor Segmentation Pipeline.
Verifies preprocessing, filtering, enhancement, brain mask extraction,
segmentation algorithms, and morphological cleanup.
"""

import unittest
import numpy as np

from src.preprocessing import clip_percentiles, normalize_min_max
from src.filtering import apply_median_filter, apply_gaussian_filter
from src.enhancement import apply_clahe, apply_histogram_equalization
from src.skull_stripping import extract_brain_mask
from src.segmentation_methods import (
    segment_global_otsu,
    segment_multi_otsu,
    segment_adaptive_local,
    segment_kmeans
)
from src.tumor_segmentation import morphological_tumor_cleanup
from src.metrics import compute_all_metrics, dice_coefficient, iou_score


class TestPipelineComponents(unittest.TestCase):
    def setUp(self):
        # Create a synthetic 100x100 slice with circular brain and bright tumor
        np.random.seed(42)
        self.image = np.zeros((100, 100), dtype=np.float32)
        y, x = np.ogrid[:100, :100]
        
        # Brain parenchyma disk (radius 40, center 50,50, intensity ~0.4)
        brain_disk = (x - 50)**2 + (y - 50)**2 <= 40**2
        self.image[brain_disk] = 0.40 + np.random.normal(0, 0.02, size=np.sum(brain_disk))
        
        # Hyperintense tumor disk (radius 12, center 55,55, intensity ~0.85)
        tumor_disk = (x - 55)**2 + (y - 55)**2 <= 12**2
        self.image[tumor_disk] = 0.85 + np.random.normal(0, 0.02, size=np.sum(tumor_disk))
        
        # Ground truth tumor mask
        self.gt_tumor = tumor_disk
        self.brain_mask = brain_disk

    def test_normalization(self):
        clipped = clip_percentiles(self.image, 0.5, 99.5)
        norm = normalize_min_max(clipped)
        self.assertAlmostEqual(norm.min(), 0.0, places=4)
        self.assertAlmostEqual(norm.max(), 1.0, places=4)

    def test_spatial_filters(self):
        med = apply_median_filter(self.image, size=3)
        self.assertEqual(med.shape, self.image.shape)
        gauss = apply_gaussian_filter(self.image, sigma=1.0)
        self.assertEqual(gauss.shape, self.image.shape)

    def test_clahe_enhancement(self):
        clahe_out = apply_clahe(self.image, clip_limit=0.03, kernel_size=(8, 8), mask=self.brain_mask)
        self.assertEqual(clahe_out.shape, self.image.shape)
        self.assertTrue(np.all(clahe_out >= 0.0) and np.all(clahe_out <= 1.0))
        # Zero outside brain mask
        self.assertTrue(np.all(clahe_out[~self.brain_mask] == 0.0))

    def test_brain_mask_extraction(self):
        mask, intermediates, stats = extract_brain_mask(self.image, thresh_method="otsu", disk_radius=3, min_size=500)
        self.assertEqual(mask.shape, self.image.shape)
        self.assertTrue(isinstance(mask, np.ndarray))
        self.assertEqual(mask.dtype, bool)
        self.assertIn("brain_area_pixels", stats)
        # Brain disk should be largely captured
        overlap = np.sum(np.logical_and(mask, self.brain_mask)) / np.sum(self.brain_mask)
        self.assertGreater(overlap, 0.90)

    def test_segmentation_methods(self):
        # 1. Global Otsu
        cand_otsu = segment_global_otsu(self.image, self.brain_mask)
        self.assertEqual(cand_otsu.dtype, bool)
        
        # 2. Multi-Otsu (3 classes)
        cand_motsu = segment_multi_otsu(self.image, self.brain_mask, classes=3)
        self.assertEqual(cand_motsu.dtype, bool)

        # 3. Adaptive Local
        cand_adapt = segment_adaptive_local(self.image, self.brain_mask, block_size=15, offset=-0.02)
        self.assertEqual(cand_adapt.dtype, bool)

        # 4. K-Means (K=3)
        cand_k3 = segment_kmeans(self.image, self.brain_mask, k=3, random_state=42)
        self.assertEqual(cand_k3.dtype, bool)

        # Clean K-Means mask and evaluate vs GT tumor
        pred_k3, _, cleanup_info = morphological_tumor_cleanup(cand_k3, disk_r_open=2, disk_r_close=2, min_size=50)
        self.assertEqual(pred_k3.dtype, bool)
        self.assertIn("final_tumor_pixels", cleanup_info)

        dsc = dice_coefficient(pred_k3, self.gt_tumor)
        # Synthetic tumor is distinct, DSC should be > 0.85
        self.assertGreater(dsc, 0.85)


if __name__ == "__main__":
    unittest.main()
