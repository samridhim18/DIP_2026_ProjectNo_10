import unittest
import numpy as np
from src.metrics import (
    dice_coefficient,
    iou_score,
    precision_score,
    recall_score,
    area_error_percent,
    confusion_matrix_counts,
    compute_all_metrics
)


class TestMetrics(unittest.TestCase):
    def test_identical_masks(self):
        y_true = np.array([
            [1, 1, 0],
            [1, 0, 0],
            [0, 0, 0]
        ], dtype=bool)
        y_pred = y_true.copy()

        self.assertEqual(dice_coefficient(y_pred, y_true), 1.0)
        self.assertEqual(iou_score(y_pred, y_true), 1.0)
        self.assertEqual(precision_score(y_pred, y_true), 1.0)
        self.assertEqual(recall_score(y_pred, y_true), 1.0)
        self.assertEqual(area_error_percent(y_pred, y_true), 0.0)

    def test_disjoint_masks(self):
        y_true = np.array([
            [1, 1, 0],
            [0, 0, 0],
            [0, 0, 0]
        ], dtype=bool)
        y_pred = np.array([
            [0, 0, 0],
            [0, 0, 0],
            [1, 1, 0]
        ], dtype=bool)

        self.assertEqual(dice_coefficient(y_pred, y_true), 0.0)
        self.assertEqual(iou_score(y_pred, y_true), 0.0)
        self.assertEqual(precision_score(y_pred, y_true), 0.0)
        self.assertEqual(recall_score(y_pred, y_true), 0.0)
        self.assertEqual(area_error_percent(y_pred, y_true), 0.0)

    def test_partial_overlap(self):
        # GT has 4 ones, Pred has 4 ones. Overlap is 2.
        # TP = 2, FP = 2, FN = 2, TN = 3
        y_true = np.array([
            [1, 1, 0],
            [1, 1, 0],
            [0, 0, 0]
        ], dtype=bool)
        y_pred = np.array([
            [0, 1, 1],
            [0, 1, 1],
            [0, 0, 0]
        ], dtype=bool)

        cm = confusion_matrix_counts(y_pred, y_true)
        self.assertEqual(cm["tp"], 2)
        self.assertEqual(cm["fp"], 2)
        self.assertEqual(cm["fn"], 2)
        self.assertEqual(cm["tn"], 3)

        # Dice = 2*2 / (4 + 4) = 4 / 8 = 0.5
        self.assertAlmostEqual(dice_coefficient(y_pred, y_true), 0.5)
        # IoU = 2 / (2 + 2 + 2) = 2 / 6 = 1/3
        self.assertAlmostEqual(iou_score(y_pred, y_true), 1.0 / 3.0)
        # Precision = 2 / 4 = 0.5
        self.assertAlmostEqual(precision_score(y_pred, y_true), 0.5)
        # Recall = 2 / 4 = 0.5
        self.assertAlmostEqual(recall_score(y_pred, y_true), 0.5)
        # Area Error = (4 - 4) / 4 = 0%
        self.assertEqual(area_error_percent(y_pred, y_true), 0.0)

    def test_empty_masks(self):
        y_true = np.zeros((3, 3), dtype=bool)
        y_pred = np.zeros((3, 3), dtype=bool)

        self.assertEqual(dice_coefficient(y_pred, y_true), 1.0)
        self.assertEqual(iou_score(y_pred, y_true), 1.0)
        self.assertEqual(precision_score(y_pred, y_true), 1.0)
        self.assertEqual(recall_score(y_pred, y_true), 1.0)
        self.assertEqual(area_error_percent(y_pred, y_true), 0.0)

    def test_one_empty_mask(self):
        y_true = np.ones((2, 2), dtype=bool)
        y_pred = np.zeros((2, 2), dtype=bool)

        self.assertEqual(dice_coefficient(y_pred, y_true), 0.0)
        self.assertEqual(iou_score(y_pred, y_true), 0.0)
        self.assertEqual(precision_score(y_pred, y_true), 0.0)
        self.assertEqual(recall_score(y_pred, y_true), 0.0)
        self.assertEqual(area_error_percent(y_pred, y_true), -100.0)

    def test_voxel_spacing_physical_units(self):
        y_true = np.ones((2, 2), dtype=bool)
        y_pred = np.ones((2, 2), dtype=bool)
        metrics = compute_all_metrics(y_pred, y_true, voxel_spacing=(1.5, 2.0))

        # 4 pixels * (1.5 * 2.0 = 3.0 mm^2) = 12.0 mm^2
        self.assertEqual(metrics["pixel_area_mm2"], 3.0)
        self.assertEqual(metrics["pred_area_mm2"], 12.0)
        self.assertEqual(metrics["gt_area_mm2"], 12.0)


if __name__ == "__main__":
    unittest.main()
