import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import wilcoxon

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

from src.pipeline import run_pipeline, load_config
from src.segmentation_methods import (
    segment_global_otsu,
    segment_multi_otsu,
    segment_adaptive_local,
    segment_kmeans
)
from src.tumor_segmentation import morphological_tumor_cleanup
from src.metrics import compute_all_metrics, dice_coefficient, iou_score, precision_score, recall_score
from src.visualization import build_evaluation_overlay_rgb


def main():
    print("=" * 80)
    print(" ECE501 DIP Project: Stage 5 - Classical Method Comparison (Part 1)")
    print("=" * 80)

    cfg = load_config()
    slice_df = pd.read_csv(os.path.join(PROJECT_ROOT, "results", "slice_list.csv"))
    tuning_df = pd.read_csv(os.path.join(PROJECT_ROOT, "results", "adaptive_tuning_grid.csv"))

    best_adaptive = tuning_df.iloc[0]
    best_bs = int(best_adaptive["block_size"])
    best_off = float(best_adaptive["offset"])
    print(f"[Config] Loaded best Adaptive params from DEV grid: block_size={best_bs}, offset={best_off}")

    methods = [
        "Global_Otsu",
        "Multi_Otsu_3Class",
        "Adaptive_Local",
        "KMeans_K2",
        "KMeans_K3",
        "KMeans_K4"
    ]

    r_open = cfg["baseline_tumor_segmentation"]["disk_r_open"]
    r_close = cfg["baseline_tumor_segmentation"]["disk_r_close"]
    min_comp_size = cfg["baseline_tumor_segmentation"]["min_component_size"]

    results = []

    print(f"\n[Step 1] Evaluating {len(methods)} methods across {len(slice_df)} slices...")

    # Group slices by patient to avoid reloading 3D volume multiple times
    grouped = slice_df.groupby("patient")
    total_processed = 0

    for patient_id, group in grouped:
        for _, row in group.iterrows():
            slice_idx = int(row["slice"])
            split = row["split"]

            # Run pipeline up to brain mask & preprocessed slice
            pipe_res = run_pipeline(patient_id, slice_idx, "flair", cfg)
            prep_slice = pipe_res["preprocessed_slice"]
            brain_mask = pipe_res["brain_mask"]
            gt_mask = pipe_res["gt_mask"]
            gt_area = int(np.sum(gt_mask))

            for m in methods:
                if m == "Global_Otsu":
                    cand = segment_global_otsu(prep_slice, brain_mask)
                elif m == "Multi_Otsu_3Class":
                    cand = segment_multi_otsu(prep_slice, brain_mask, classes=3)
                elif m == "Adaptive_Local":
                    cand = segment_adaptive_local(prep_slice, brain_mask, block_size=best_bs, offset=best_off)
                elif m == "KMeans_K2":
                    cand = segment_kmeans(prep_slice, brain_mask, k=2, random_state=42)
                elif m == "KMeans_K3":
                    cand = segment_kmeans(prep_slice, brain_mask, k=3, random_state=42)
                elif m == "KMeans_K4":
                    cand = segment_kmeans(prep_slice, brain_mask, k=4, random_state=42)
                else:
                    raise ValueError(f"Unknown method {m}")

                # Apply identical morphological cleanup
                cleaned_mask, _, _ = morphological_tumor_cleanup(
                    cand, disk_r_open=r_open, disk_r_close=r_close, min_size=min_comp_size
                )
                pred_area = int(np.sum(cleaned_mask))

                # Compute metrics
                d = dice_coefficient(cleaned_mask, gt_mask)
                j = iou_score(cleaned_mask, gt_mask)
                p = precision_score(cleaned_mask, gt_mask)
                r = recall_score(cleaned_mask, gt_mask)

                results.append({
                    "patient": patient_id,
                    "slice": slice_idx,
                    "split": split,
                    "method": m,
                    "dice": round(d, 4),
                    "iou": round(j, 4),
                    "precision": round(p, 4),
                    "recall": round(r, 4),
                    "pred_area": pred_area,
                    "gt_area": gt_area
                })

            total_processed += 1
            if total_processed % 25 == 0 or total_processed == len(slice_df):
                print(f" Processed {total_processed}/{len(slice_df)} slices...")

    # Save per-slice CSV
    res_df = pd.DataFrame(results)
    per_slice_path = os.path.join(PROJECT_ROOT, "results", "stage5_per_slice.csv")
    res_df.to_csv(per_slice_path, index=False)
    print(f"[INFO] Saved per-slice results to: {per_slice_path}")

    # Step 2: Compute summary statistics for TEST and DEV splits
    print("\n[Step 2] Computing summary statistics and Wilcoxon tests on TEST split...")
    test_df = res_df[res_df["split"] == "TEST"]
    dev_df = res_df[res_df["split"] == "DEV"]

    def compute_split_summary(df, is_test=True):
        summary_rows = []
        baseline_dice = df[df["method"] == "Global_Otsu"].sort_values(by=["patient", "slice"])["dice"].values

        for m in methods:
            m_sub = df[df["method"] == m].sort_values(by=["patient", "slice"])
            m_dice = m_sub["dice"].values

            # Wilcoxon test vs Global_Otsu on Dice
            if m == "Global_Otsu":
                w_stat, p_val = np.nan, np.nan
            else:
                # differences
                diff = m_dice - baseline_dice
                if np.all(diff == 0):
                    w_stat, p_val = 0.0, 1.0
                else:
                    try:
                        res_w = wilcoxon(m_dice, baseline_dice, alternative='two-sided', zero_method='wilcox')
                        w_stat, p_val = res_w.statistic, res_w.pvalue
                    except Exception as e:
                        w_stat, p_val = np.nan, np.nan

            summary_rows.append({
                "method": m,
                "dice_mean": round(float(np.mean(m_sub["dice"])), 4),
                "dice_std": round(float(np.std(m_sub["dice"])), 4),
                "dice_median": round(float(np.median(m_sub["dice"])), 4),
                "dice_min": round(float(np.min(m_sub["dice"])), 4),
                "dice_max": round(float(np.max(m_sub["dice"])), 4),
                "iou_mean": round(float(np.mean(m_sub["iou"])), 4),
                "iou_std": round(float(np.std(m_sub["iou"])), 4),
                "iou_median": round(float(np.median(m_sub["iou"])), 4),
                "prec_mean": round(float(np.mean(m_sub["precision"])), 4),
                "prec_std": round(float(np.std(m_sub["precision"])), 4),
                "rec_mean": round(float(np.mean(m_sub["recall"])), 4),
                "rec_std": round(float(np.std(m_sub["recall"])), 4),
                "wilcoxon_stat": round(float(w_stat), 2) if not np.isnan(w_stat) else "N/A",
                "p_value": f"{p_val:.2e}" if not np.isnan(p_val) else "N/A"
            })
        return pd.DataFrame(summary_rows)

    test_summary = compute_split_summary(test_df, is_test=True)
    dev_summary = compute_split_summary(dev_df, is_test=False)

    test_summary_path = os.path.join(PROJECT_ROOT, "results", "stage5_test_metrics.csv")
    dev_summary_path = os.path.join(PROJECT_ROOT, "results", "stage5_dev_metrics.csv")
    test_summary.to_csv(test_summary_path, index=False)
    dev_summary.to_csv(dev_summary_path, index=False)

    print(f"[INFO] Saved TEST split summary to: {test_summary_path}")
    print(f"[INFO] Saved DEV split summary to: {dev_summary_path}")

    # Step 3: Generate Boxplot Figure of Dice per method
    print("\n[Step 3] Generating Boxplot and Qualitative Comparison Figures...")
    plt.style.use('dark_background')
    fig, ax = plt.subplots(figsize=(11, 6), dpi=150)

    data_to_plot = [test_df[test_df["method"] == m]["dice"].values for m in methods]
    labels = ["Global Otsu", "Multi-Otsu (3C)", "Adaptive Local", "K-Means (K=2)", "K-Means (K=3)", "K-Means (K=4)"]

    bp = ax.boxplot(
        data_to_plot,
        tick_labels=labels,
        patch_artist=True,
        notch=True,
        boxprops=dict(facecolor='#1f77b4', color='white', alpha=0.7),
        capprops=dict(color='white'),
        whiskerprops=dict(color='gray'),
        flierprops=dict(marker='o', color='white', markeredgecolor='gray', markersize=3),
        medianprops=dict(color='yellow', linewidth=2)
    )

    # Color each box with distinctive palette
    colors = ['#1f77b4', '#2ca02c', '#ff7f0e', '#d62728', '#9467bd', '#8c564b']
    for patch, c in zip(bp['boxes'], colors):
        patch.set_facecolor(c)

    ax.set_title("TEST Split (N=150 Slices): Dice Coefficient Distribution by Method", fontsize=13, fontweight='bold', pad=10)
    ax.set_ylabel("Sørensen-Dice Coefficient", fontsize=11)
    ax.set_ylim(-0.05, 1.05)
    ax.grid(True, linestyle='--', alpha=0.3)
    plt.xticks(rotation=15, ha='right', fontsize=10)
    plt.tight_layout()

    boxplot_path = os.path.join(PROJECT_ROOT, "results", "stage5_dice_boxplot.png")
    plt.savefig(boxplot_path, bbox_inches='tight', dpi=200)
    plt.close(fig)
    print(f"[INFO] Saved Dice boxplot to: {boxplot_path}")

    # Step 4: Find median-performance test slice and generate qualitative figure
    # Determine best method on DEV split
    best_dev_method = dev_summary.sort_values(by="dice_mean", ascending=False).iloc[0]["method"]
    print(f"\n[Selection] Best method on DEV split by Mean Dice: {best_dev_method}")

    # Find slice in TEST set closest to median Dice for this best method
    test_best_m = test_df[test_df["method"] == best_dev_method].copy()
    median_dice_val = np.median(test_best_m["dice"])
    test_best_m["dist_to_med"] = np.abs(test_best_m["dice"] - median_dice_val)
    med_row = test_best_m.sort_values(by="dist_to_med").iloc[0]

    med_patient = med_row["patient"]
    med_slice = int(med_row["slice"])
    print(f" Representative median test slice: {med_patient}, Slice {med_slice} (Dice: {med_row['dice']:.4f})")

    # Generate predictions for all methods on this median slice
    med_res = run_pipeline(med_patient, med_slice, "flair", cfg)
    prep_slice = med_res["preprocessed_slice"]
    brain_mask = med_res["brain_mask"]
    gt_mask = med_res["gt_mask"]

    fig2, axes = plt.subplots(2, 4, figsize=(18, 9), dpi=150)
    axes_flat = axes.flatten()

    # Panel 0: FLAIR
    axes_flat[0].imshow(prep_slice, cmap='gray', vmin=0, vmax=1)
    axes_flat[0].set_title(f"Preprocessed FLAIR\n({med_patient} Sl {med_slice})", fontsize=11, fontweight='bold')
    axes_flat[0].axis('off')

    # Panel 1: Ground Truth
    axes_flat[1].imshow(prep_slice, cmap='gray', vmin=0, vmax=1)
    axes_flat[1].imshow(np.ma.masked_where(~gt_mask, gt_mask), cmap='spring', alpha=0.6)
    axes_flat[1].set_title(f"Ground Truth Whole Tumor\nArea: {int(np.sum(gt_mask))} px", fontsize=11, fontweight='bold')
    axes_flat[1].axis('off')

    for idx, m in enumerate(methods):
        ax = axes_flat[idx + 2]
        if m == "Global_Otsu":
            cand = segment_global_otsu(prep_slice, brain_mask)
        elif m == "Multi_Otsu_3Class":
            cand = segment_multi_otsu(prep_slice, brain_mask, classes=3)
        elif m == "Adaptive_Local":
            cand = segment_adaptive_local(prep_slice, brain_mask, block_size=best_bs, offset=best_off)
        elif m == "KMeans_K2":
            cand = segment_kmeans(prep_slice, brain_mask, k=2, random_state=42)
        elif m == "KMeans_K3":
            cand = segment_kmeans(prep_slice, brain_mask, k=3, random_state=42)
        elif m == "KMeans_K4":
            cand = segment_kmeans(prep_slice, brain_mask, k=4, random_state=42)

        cln, _, _ = morphological_tumor_cleanup(cand, disk_r_open=r_open, disk_r_close=r_close, min_size=min_comp_size)
        d_val = dice_coefficient(cln, gt_mask)
        j_val = iou_score(cln, gt_mask)

        tp = np.logical_and(cln, gt_mask)
        fp = np.logical_and(cln, ~gt_mask)
        fn = np.logical_and(~cln, gt_mask)
        overlay_rgb = build_evaluation_overlay_rgb(prep_slice, tp, fp, fn)

        ax.imshow(overlay_rgb)
        ax.set_title(f"{m}\nDice: {d_val:.4f} | IoU: {j_val:.4f}", fontsize=10.5, fontweight='bold')
        ax.axis('off')

    fig2.suptitle(
        f"Stage 5 Qualitative Method Comparison (Representative Median Slice: {med_patient}, Slice {med_slice})",
        fontsize=14, fontweight='bold', y=0.98
    )
    plt.tight_layout()

    qual_path = os.path.join(PROJECT_ROOT, "results", "stage5_qualitative_median_slice.png")
    plt.savefig(qual_path, bbox_inches='tight', dpi=200)
    plt.close(fig2)
    print(f"[INFO] Saved qualitative comparison figure to: {qual_path}")

    print("\n" + "=" * 80)
    print(" PART 1 EXECUTION COMPLETE")
    print("=" * 80)


if __name__ == "__main__":
    main()
