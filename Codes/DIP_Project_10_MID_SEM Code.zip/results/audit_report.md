# Project Audit & Fix Report: Stages 1–4

**Project**: ECE501 Digital Image Processing (Group 10)  
**Title**: Brain MRI Tumor Segmentation and Quantitative Analysis Using Classical Image Processing  
**Dataset**: BraTS2020 (`BraTS20_Training_001` to `369`, Modalities: FLAIR, T1, T1ce, T2; Ground Truth: `seg > 0`)  
**Audit Date**: October 10, 2026  

---

## 1. Audit Summary Table

| Issue | Found? | What Was Changed | Before | After |
| :--- | :---: | :--- | :--- | :--- |
| **A2: Skull-Stripping Status** | **Yes** | Analyzed raw un-normalized FLAIR volume & slice 67. Discovered 84.96% of volume and 70.39% of slice are exactly 0.0 with outer borders at 0.0. Clarified in reports that BraTS is pre-skull-stripped. | Misleadingly described as physical skull removal. | Accurately designated as **intracranial brain-region mask extraction and boundary regularization** on pre-stripped volumes. |
| **A3: Stage 3 Reference Mask Inconsistency** | **Yes** | Found in code that `ref_brain_mask = (original_slice > 0)`. Fixed inconsistent `0.9856` text in `stage3_summary.md`. | `stage3_summary.md` claimed Dice 0.9856 while metric file reported 0.9599. Reference mask source unexplained. | Both files report **0.9599** (IoU **0.9229**). Explicitly documented that reference is the raw non-zero region. |
| **A4: Stage 2 Background Spike & Mask-Awareness** | **Yes** | HistEq and CLAHE were unmasked on background zeros, creating a huge spike (~40,000 px) at intensity 0 in the histogram. Re-implemented HistEq and CLAHE with explicit foreground masking (`[~brain_mask] = 0.0`) and restricted histogram plotting to brain pixels only. | Overlaid histogram showed massive spike at 0.0 from background air voxels. | Overlaid histogram plot visualizes **brain tissue only** across $[0.0, 1.0]$. |
| **A4: Redundant "RMS Contrast" in Stage 2** | **Yes** | In Stage 2, "RMS contrast" was calculated as `std` (identical numbers). Replaced with **Mean Gradient Magnitude** (Sobel edge strength) and **Tumor-vs-Normal Tissue Contrast** ($mean(tumor) - mean(normal)$ using GT strictly as a measuring mask). | Redundant column where `RMS Contrast` $\equiv$ `Std Dev`. | Added meaningful DIP measures: **Edge Strength (MeanGrad)** and **Tumor-vs-Normal Contrast**. |
| **A4: Stage 2 CLAHE Contrast Claim** | **Yes** | `stage2_summary.md` claimed CLAHE "significantly enhances contrast" while std was actually $0.2121$ vs $0.2153$ (Original). Rewrote explanations to reflect that CLAHE improves **local entropy and edge gradients**, not global variance. | Misleading text claiming CLAHE drastically boosted global contrast. | Text matches data: CLAHE boosts **Entropy (7.6975 vs 7.4205)** and **MeanGrad (0.7794 vs 0.4027)**, while global std is slightly lower (0.2121). |
| **A5: Hardcoded Scripts & Reusability** | **Yes** | Refactored all parameters into `src/config.yaml`. Created `src/metrics.py` (with zero-division guards), `tests/test_metrics.py`, and `src/pipeline.py` (`run_pipeline` accepting any `patient_id` and `slice_idx`). | Parameters hardcoded inside standalone scripts; patient 001 and slice 67 hardcoded. | Fully modular architecture driven by `src/config.yaml`, unit-tested metrics, and automated patient directory resolver. |
| **A6: Multi-Patient & Slice Sampling Protocol** | **Yes** | Formulated reproducible protocol in `results/selection_protocol.md`. Sampled 20 patients (`seed=42`) from 369 training patients: 5 DEV (tuning permitted) and 15 TEST (held-out). Sampled 10 evenly spaced slices ($\ge 200$ px GT) per patient. Generated `results/slice_list.csv`. | Evaluated only 1 patient on 1 slice. No structured train/test partitioning. | Formal benchmark of **200 slices** across 20 patients (50 DEV, 150 TEST) saved in `results/slice_list.csv`. |
| **A7: Stage 4 Baseline Segmentation Verification** | **Yes** | Re-ran Stage 4 for Patient 001 Slice 67 using the refactored pipeline and `src/metrics.py`. | Pred: 4045 px, TP: 3698, FP: 347, FN: 1350, Dice: 0.8134, IoU: 0.6854. | Pred: 4044 px, TP: 3698, FP: 346, FN: 1350, Dice: **0.8135**, IoU: **0.6856** (1 fewer FP pixel due to mask zeroing). |

---

## 2. Detailed Findings

### A2. BraTS Skull Stripping Audit
- **3D Volume Statistics (`BraTS20_Training_001_flair.nii`)**:
  - Total Voxels: $8,928,000$
  - Exactly Zero Voxels: $7,585,115$ (**84.96%** of volume is exactly zero)
- **Slice 67 Statistics**:
  - Total Pixels: $57,600$ ($240 \times 240$)
  - Exactly Zero Pixels: $40,544$ (**70.39%** of slice is zero-padded background)
  - Non-Zero Voxels: $17,056$
  - Bounding Box: Rows $[49, 183]$, Columns $[48, 214]$ (Height: $135$, Width: $167$)
  - All outer margins (first/last 10 rows and columns) are strictly zero.
- **Verdict**: BraTS2020 volumes are **already skull-stripped** by the challenge organizers. Stage 3 is therefore **intracranial brain-region mask extraction and outer sulcal smoothing**, not bone/scalp tissue stripping.

### A3. Stage 3 Reference Mask Audit
- **Reference Mask Construction**: Built in code as `ref_brain_mask = (original_slice > 0)`.
- **Finding**: Because BraTS volumes are pre-skull-stripped, this reference is simply the non-zero region of the input FLAIR slice.
- **Resolution**:
  - The Dice score of **0.9599** (IoU **0.9229**) measures agreement between the morphologically regularized brain mask ($15,751$ px) and the raw non-zero voxel area ($17,056$ px), rather than accuracy against an independent manual skull-stripping label.
  - The conflicting text `0.9856` in `stage3_summary.md` was corrected to match the code output `0.9599`.

### A4. Stage 2 Preprocessing Metrics (Audit & Refactored)
Evaluated strictly over non-zero brain pixels ($N = 17,010$):

| Method | Mean ($\mu$) | Std Dev ($\sigma$) | Shannon Entropy | Edge Strength (MeanGrad) | Tumor-vs-Normal Contrast |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Original FLAIR** | `0.4331` | `0.2153` | `7.4205` | `0.4027` | `0.3754` |
| **Gaussian Filter ($\sigma=1.0$)** | `0.4297` | `0.2072` | `7.3645` | `0.2832` | `0.3740` |
| **Median Filter ($k=3$)** | `0.4318` | `0.2110` | `7.3023` | `0.3125` | `0.3752` |
| **Histogram Equalization** | `0.5035` | `0.2879` | `7.3791` | `0.6431` | `0.4726` |
| **CLAHE ($\text{clip}=0.03$)** | `0.4751` | `0.2121` | **`7.6975`** | **`0.7794`** | `0.2521` |

- **Key Takeaway**: CLAHE does not inflate global intensity standard deviation; its measurable advantages are **information entropy (7.6975 bits)** and **mean gradient edge strength (0.7794)**, preserving local tissue contrast without global saturation.

### A7. Stage 4 Baseline Segmentation: BEFORE vs AFTER

| Metric | BEFORE (Audit Baseline) | AFTER (Refactored Pipeline) | Difference / Explanation |
| :--- | :---: | :---: | :--- |
| **Patient / Slice** | Patient 001, Slice 67 | Patient 001, Slice 67 | Unchanged |
| **Stage 3 Brain Area** | `15,751` px | `15,735` px | $-16$ px (difference between 3D volume vs 2D slice percentile clipping) |
| **Brain ROI Otsu Threshold** | `0.5332` | `0.5332` | Identical |
| **Ground-Truth Tumor Area** | `5,048` px | `5,048` px | Identical |
| **Predicted Tumor Area** | `4,045` px | `4,044` px | $-1$ px |
| **True Positives (TP)** | `3,698` px | `3,698` px | **Identical** |
| **False Positives (FP)** | `347` px | `346` px | **$-1$ px** (mask-aware CLAHE strictly zeroes outer boundary) |
| **False Negatives (FN)** | `1,350` px | `1,350` px | **Identical** |
| **Sørensen–Dice Score** | `0.8134` | **`0.8135`** | $+0.0001$ |
| **Jaccard IoU Index** | `0.6854` | **`0.6856`** | $+0.0002$ |
| **Precision** | `0.9142` | **`0.9144`** | $+0.0002$ |
| **Recall** | `0.7326` | `0.7326` | **Identical** |

---

## 3. Remaining Limitations & Risks to Honestly Disclose

1. **Dataset Pre-Processing Nature**:
   - Because BraTS volumes are already skull-stripped and registered to the SRI24 atlas, the "skull-stripping" stage cannot be claimed as a novel clinical skull stripper for raw DICOM scans. It must be described as **intracranial brain ROI extraction and boundary regularization**.
2. **Edema vs Tumor Core Under-Segmentation**:
   - Global Otsu thresholding ($T = 0.5332$) inside the brain ROI captures hyperintense enhancing tumor core (ET) and dense non-enhancing core (NCR), but misses subtle peritumoral edema (ED) whose intensity overlaps with healthy white matter ($FN = 1,350$ voxels, Recall = $73.26\%$).
3. **White Matter False Positives**:
   - Some hyperintense normal white matter tracts adjacent to the tumor margin fall above the global Otsu threshold, causing $346$ false positive pixels ($Precision = 91.44\%$).
4. **2D Slice vs 3D Context**:
   - Evaluating on independent 2D axial slices ignores inter-slice volumetric continuity, which will be addressed when aggregating multi-slice metrics across the benchmark cohort.
5. **No Deep Learning Guarantee**:
   - The entire pipeline operates strictly on deterministic classical image processing operators (linear/non-linear filtering, histogram redistribution, Otsu variance optimization, and morphological set operations), with zero neural network or machine learning components.
