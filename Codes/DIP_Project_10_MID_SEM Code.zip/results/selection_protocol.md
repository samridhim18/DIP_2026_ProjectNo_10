# BraTS2020 Patient and Slice Selection Protocol

**Project**: ECE501 Digital Image Processing (Group 10)  
**Task**: Brain MRI Tumor Segmentation and Quantitative Analysis Using Classical Image Processing  

---

## 1. Objective

To establish a reproducible, unbiased experimental benchmark for classical DIP methods across multiple subjects without data leakage or hyperparameter over-fitting.

---

## 2. Patient Cohort Selection

- **Sampling Source**: Full BraTS 2020 Training Set ($N = 369$ subjects: `BraTS20_Training_001` through `BraTS20_Training_369`).
- **Random Seed**: Fixed random seed `seed = 42` using Python's standard `random.sample(sorted(all_patients), 20)`.
- **Dataset Partitioning**:
  - **DEV Set (5 Patients, 50 Slices)**: Allowed for classical parameter exploration (filter sizes, thresholding heuristics, morphological disk radii).
    - `BraTS20_Training_328`
    - `BraTS20_Training_058`
    - `BraTS20_Training_013`
    - `BraTS20_Training_141`
    - `BraTS20_Training_126`
  - **TEST Set (15 Patients, 150 Slices)**: Strictly held out for final evaluation. Parameters will **never** be tuned on this set.
    - `BraTS20_Training_115`, `BraTS20_Training_072`, `BraTS20_Training_053`, `BraTS20_Training_347`, `BraTS20_Training_280`
    - `BraTS20_Training_045`, `BraTS20_Training_303`, `BraTS20_Training_217`, `BraTS20_Training_017`, `BraTS20_Training_016`
    - `BraTS20_Training_048`, `BraTS20_Training_112`, `BraTS20_Training_120`, `BraTS20_Training_259`, `BraTS20_Training_309`

---

## 3. Slice Selection Rules

For each of the 20 selected patients:
1. **Tumor Burden Threshold**: Filter all 2D axial slices where Ground-Truth whole tumor ($seg > 0$) area is $\ge 200$ pixels. This removes slices containing negligible border voxels or volume averaging artifacts.
2. **Evenly Spaced Sampling**: From the valid slice range, sample up to **10 slices evenly spaced** across the tumor volume using `np.linspace(0, len(valid_slices) - 1, 10, dtype=int)` (rather than selecting only the top-10 slices with largest tumor area). This ensures evaluation covers slices with varying tumor cross-sections, ranging from small apical margins to central high-burden slices.
3. **Record Keeping**: All selected slices are compiled in [`results/slice_list.csv`](file:///Users/sam/Desktop/DIP_2026_Project_10/BraTS20_Training_001/results/slice_list.csv) with columns: `patient, slice, gt_area_px, split`.

---

## 4. Ground-Truth Usage Constraint (Hard Rule)

- The ground-truth segmentation (`seg.nii`) is strictly used **ONLY** for:
  1. Identifying slices that meet the $\ge 200$ pixel inclusion criterion.
  2. Quantitative validation metrics (Dice, IoU, Precision, Recall, Area Error).
- Ground truth is **never** used during image preprocessing, threshold estimation, morphological cleanup, or component selection.
