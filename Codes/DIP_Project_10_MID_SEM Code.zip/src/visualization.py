import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from typing import Optional, Tuple, Dict, Any


def get_brats_cmap() -> Tuple[mcolors.ListedColormap, mcolors.BoundaryNorm]:
    """
    Constructs a custom discrete Colormap and Normalizer for BraTS segmentation labels.
    """
    colors = [
        [0.0, 0.0, 0.0, 0.0],   # 0: Background (Transparent)
        [0.85, 0.1, 0.1, 0.85], # 1: NCR/NET (Red)
        [0.1, 0.75, 0.2, 0.7],  # 2: ED (Green)
        [1.0, 0.85, 0.0, 0.9],  # 4: ET (Yellow)
    ]
    cmap = mcolors.ListedColormap(colors)
    bounds = [-0.5, 0.5, 1.5, 3.5, 4.5]
    norm = mcolors.BoundaryNorm(bounds, cmap.N)
    return cmap, norm


def plot_mri_and_mask(
    mri_slice: np.ndarray,
    mask_slice: np.ndarray,
    slice_idx: int,
    title_prefix: str = "BraTS20_Training_001",
    alpha: float = 0.5,
    save_path: Optional[str] = None,
    show_plot: bool = False
) -> None:
    """
    Creates a 4-panel Stage 1 visualization figure.
    """
    plt.style.use('dark_background')
    fig, axes = plt.subplots(1, 4, figsize=(20, 5), dpi=150)
    cmap, norm = get_brats_cmap()

    im0 = axes[0].imshow(mri_slice, cmap='gray')
    axes[0].set_title(f"FLAIR MRI (Slice {slice_idx})", fontsize=12, fontweight='bold', pad=10)
    axes[0].axis('off')
    fig.colorbar(im0, ax=axes[0], fraction=0.046, pad=0.04, label="Intensity")

    im1 = axes[1].imshow(mask_slice, cmap=cmap, norm=norm)
    axes[1].set_title(f"Ground-Truth Mask (Slice {slice_idx})", fontsize=12, fontweight='bold', pad=10)
    axes[1].axis('off')

    cbar1 = fig.colorbar(im1, ax=axes[1], fraction=0.046, pad=0.04, ticks=[0, 1, 2, 4])
    cbar1.ax.set_yticklabels(['0: BG', '1: NCR', '2: ED', '4: ET'], fontsize=9)

    axes[2].imshow(mri_slice, cmap='gray')
    axes[2].imshow(mask_slice, cmap=cmap, norm=norm, alpha=alpha)
    axes[2].set_title(f"MRI + Mask Overlay (α={alpha})", fontsize=12, fontweight='bold', pad=10)
    axes[2].axis('off')

    nonzero_mri = mri_slice[mri_slice > 0]
    if len(nonzero_mri) > 0:
        axes[3].hist(nonzero_mri.ravel(), bins=50, color='#1f77b4', edgecolor='black', alpha=0.85)
        axes[3].set_title("FLAIR Intensity Histogram", fontsize=12, fontweight='bold', pad=10)
        axes[3].set_xlabel("Normalized Intensity")
        axes[3].set_ylabel("Voxel Count")
        axes[3].grid(True, linestyle='--', alpha=0.3)
    else:
        axes[3].text(0.5, 0.5, "No Foreground Voxels", ha='center', va='center')
        axes[3].axis('off')

    fig.suptitle(f"{title_prefix} - Axial Slice {slice_idx} Inspection", fontsize=14, fontweight='bold', y=0.98)
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        plt.savefig(save_path, bbox_inches='tight', dpi=200)
        print(f"[INFO] Saved Stage 1 plot to: {os.path.abspath(save_path)}")

    if show_plot:
        plt.show()
    
    plt.close(fig)


def plot_preprocessing_comparison(
    images_dict: Dict[str, np.ndarray],
    metrics_dict: Dict[str, Dict[str, float]],
    slice_idx: int,
    save_path: Optional[str] = None
) -> None:
    """
    Renders a 5-panel side-by-side visual comparison for Stage 2 Preprocessing.
    """
    plt.style.use('dark_background')
    fig, axes = plt.subplots(1, 5, figsize=(25, 5.5), dpi=150)

    method_titles = {
        "Original": "Original FLAIR",
        "Gaussian": "Gaussian Filtered (σ=1)",
        "Median": "Median Filtered (k=3)",
        "HistEq": "Histogram Equalized",
        "CLAHE": "CLAHE (Clip=0.03)"
    }

    for idx, (key, title) in enumerate(method_titles.items()):
        ax = axes[idx]
        img = images_dict[key]
        met = metrics_dict[key]

        im = ax.imshow(img, cmap='gray', vmin=0.0, vmax=1.0)
        ax.set_title(title, fontsize=12, fontweight='bold', pad=8)
        ax.axis('off')

        stats_text = (
            f"Mean: {met['mean']:.3f}\n"
            f"Std: {met['std']:.3f}\n"
            f"Entropy: {met['entropy']:.3f}\n"
            f"Grad: {met['mean_gradient']:.3f}"
        )
        if "tumor_vs_normal_contrast" in met:
            stats_text += f"\nContrast: {met['tumor_vs_normal_contrast']:.3f}"

        ax.text(
            0.04, 0.04, stats_text,
            transform=ax.transAxes,
            fontsize=8.5,
            verticalalignment='bottom',
            bbox=dict(boxstyle='round,pad=0.4', facecolor='black', alpha=0.75, edgecolor='gray')
        )

    fig.suptitle(
        f"Stage 2: Classical MRI Preprocessing & Enhancement Comparison (Axial Slice {slice_idx})",
        fontsize=15, fontweight='bold', y=0.98
    )
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        plt.savefig(save_path, bbox_inches='tight', dpi=200)
        print(f"[INFO] Saved Stage 2 comparison plot to: {os.path.abspath(save_path)}")

    plt.close(fig)


def plot_histogram_comparison(
    images_dict: Dict[str, np.ndarray],
    slice_idx: int,
    brain_mask: Optional[np.ndarray] = None,
    save_path: Optional[str] = None
) -> None:
    """
    Renders overlaid histogram distributions for Stage 2 evaluated strictly within the brain mask.
    """
    plt.style.use('dark_background')
    fig, ax = plt.subplots(figsize=(10, 5), dpi=150)

    colors = {
        "Original": "#1f77b4",
        "Gaussian": "#2ca02c",
        "Median": "#ff7f0e",
        "HistEq": "#d62728",
        "CLAHE": "#9467bd"
    }

    for key, img in images_dict.items():
        if brain_mask is not None:
            pixels = img[brain_mask]
        else:
            pixels = img[img > 0]

        if len(pixels) > 0:
            counts, bin_edges = np.histogram(pixels, bins=100, range=(0.0, 1.0))
            bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2.0
            ax.plot(bin_centers, counts, label=key, color=colors.get(key, 'white'), linewidth=2, alpha=0.85)

    ax.set_title(f"Brain Tissue Intensity Histogram Comparison (Slice {slice_idx})", fontsize=13, fontweight='bold')
    ax.set_xlabel("Normalized Intensity")
    ax.set_ylabel("Voxel Count")
    ax.grid(True, linestyle='--', alpha=0.3)
    ax.legend(loc='upper right', fontsize=10)
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        plt.savefig(save_path, bbox_inches='tight', dpi=200)
        print(f"[INFO] Saved Stage 2 histogram comparison plot to: {os.path.abspath(save_path)}")

    plt.close(fig)


def plot_skull_stripping_pipeline(
    pipeline_dict: Dict[str, np.ndarray],
    slice_idx: int,
    stats: Dict[str, Any],
    save_path: Optional[str] = None
) -> None:
    """
    Renders a 6-panel figure showcasing the step-by-step Skull Stripping pipeline.
    """
    plt.style.use('dark_background')
    fig, axes = plt.subplots(2, 3, figsize=(18, 11), dpi=150)
    axes_flat = axes.flatten()

    panels = [
        ("1. Original FLAIR", pipeline_dict["original"], "gray"),
        ("2. Preprocessed (Median+CLAHE)", pipeline_dict["preprocessed"], "gray"),
        ("3. Initial Binary Mask (Otsu)", pipeline_dict["initial"], "plasma"),
        ("4. Cleaned & Filled Mask", pipeline_dict["filled"], "plasma"),
        ("5. Final Brain Mask", pipeline_dict["final_brain_mask"], "viridis"),
        ("6. Skull-Stripped MRI", pipeline_dict["skull_stripped"], "gray"),
    ]

    for idx, (title, img, colormap) in enumerate(panels):
        ax = axes_flat[idx]
        if colormap == "gray":
            im = ax.imshow(img, cmap='gray', vmin=0.0, vmax=1.0)
        else:
            im = ax.imshow(img, cmap=colormap)

        ax.set_title(title, fontsize=12, fontweight='bold', pad=8)
        ax.axis('off')

        if idx == 4:
            txt = (
                f"Area: {stats['brain_area_pixels']:,} px\n"
                f"Coverage: {stats['percentage_occupied']:.2f}%\n"
                f"Dice vs GT: {stats.get('dice_coefficient', 'N/A')}"
            )
            ax.text(
                0.04, 0.04, txt,
                transform=ax.transAxes,
                fontsize=9,
                verticalalignment='bottom',
                bbox=dict(boxstyle='round,pad=0.4', facecolor='black', alpha=0.8, edgecolor='yellow')
            )

    fig.suptitle(
        f"Stage 3: Classical Skull Stripping Pipeline (Axial Slice {slice_idx})",
        fontsize=16, fontweight='bold', y=0.98
    )
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        plt.savefig(save_path, bbox_inches='tight', dpi=200)
        print(f"[INFO] Saved Stage 3 skull stripping pipeline figure to: {os.path.abspath(save_path)}")

    plt.close(fig)


def build_evaluation_overlay_rgb(
    base_mri: np.ndarray,
    tp_map: np.ndarray,
    fp_map: np.ndarray,
    fn_map: np.ndarray
) -> np.ndarray:
    """
    Builds an RGB overlay image showing confusion matrix categories:
      - True Positive (TP)  : Green (0, 255, 0)
      - False Positive (FP) : Red (255, 0, 0)
      - False Negative (FN) : Cyan/Yellow (255, 255, 0)
    """
    # Convert base MRI to 3-channel RGB [0, 1]
    norm_mri = np.clip(base_mri, 0.0, 1.0)
    rgb = np.stack([norm_mri, norm_mri, norm_mri], axis=-1)

    # Apply TP (Green)
    rgb[tp_map] = [0.0, 1.0, 0.2]
    # Apply FP (Red)
    rgb[fp_map] = [1.0, 0.15, 0.15]
    # Apply FN (Yellow)
    rgb[fn_map] = [1.0, 0.85, 0.0]

    return rgb


def plot_stage4_baseline_segmentation(
    img_dict: Dict[str, np.ndarray],
    metrics: Dict[str, Any],
    slice_idx: int,
    thresh_val: float,
    save_path: Optional[str] = None
) -> None:
    """
    Creates the required 2x3 baseline tumor segmentation figure:
      Panel 1: Skull-stripped FLAIR
      Panel 2: Brain ROI / brain mask
      Panel 3: Initial Otsu tumor candidate
      Panel 4: Morphologically cleaned tumor mask
      Panel 5: Ground-truth tumor mask
      Panel 6: Final predicted tumor vs ground truth overlay (TP/FP/FN)
    """
    plt.style.use('dark_background')
    fig, axes = plt.subplots(2, 3, figsize=(18, 11), dpi=150)
    axes_flat = axes.flatten()

    overlay_rgb = build_evaluation_overlay_rgb(
        img_dict["skull_stripped"],
        metrics["tp_map"],
        metrics["fp_map"],
        metrics["fn_map"]
    )

    panels = [
        ("1. Skull-Stripped FLAIR", img_dict["skull_stripped"], "gray"),
        ("2. Brain ROI Mask", img_dict["brain_mask"], "Blues_r"),
        ("3. Initial Otsu Candidate", img_dict["initial_candidate"], "magma"),
        ("4. Cleaned Tumor Mask", img_dict["cleaned_mask"], "spring"),
        ("5. Ground-Truth Tumor Mask", img_dict["ground_truth"], "YlOrRd"),
        ("6. Prediction vs Ground Truth Overlay", overlay_rgb, "rgb")
    ]

    for idx, (title, img, colormap) in enumerate(panels):
        ax = axes_flat[idx]
        if colormap == "gray":
            ax.imshow(img, cmap='gray', vmin=0.0, vmax=1.0)
        elif colormap == "rgb":
            ax.imshow(img)
        else:
            ax.imshow(img, cmap=colormap)

        ax.set_title(title, fontsize=12, fontweight='bold', pad=8)
        ax.axis('off')

        if idx == 2:
            ax.text(
                0.04, 0.04, f"Otsu Thresh: {thresh_val:.4f}",
                transform=ax.transAxes, fontsize=9,
                bbox=dict(boxstyle='round', facecolor='black', alpha=0.75, edgecolor='gray')
            )

        if idx == 5:
            # Legend for overlay panel
            legend_text = (
                f"Dice: {metrics['dice']:.4f} | IoU: {metrics['iou']:.4f}\n"
                f"■ Green : True Positive (TP: {metrics['tp_count']})\n"
                f"■ Red   : False Positive (FP: {metrics['fp_count']})\n"
                f"■ Yellow: False Negative (FN: {metrics['fn_count']})"
            )
            ax.text(
                0.03, 0.03, legend_text,
                transform=ax.transAxes, fontsize=8.5,
                bbox=dict(boxstyle='round,pad=0.5', facecolor='black', alpha=0.85, edgecolor='lime')
            )

    fig.suptitle(
        f"Stage 4: Baseline Classical Tumor Segmentation (Axial Slice {slice_idx})",
        fontsize=16, fontweight='bold', y=0.98
    )
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        plt.savefig(save_path, bbox_inches='tight', dpi=200)
        print(f"[INFO] Saved Stage 4 baseline segmentation 2x3 figure to: {os.path.abspath(save_path)}")

    plt.close(fig)
