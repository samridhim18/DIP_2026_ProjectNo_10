"""
compute_extended_results.py
Calculates:
1. Modality comparison across TEST set (FLAIR, T1, T1ce, T2 on WT; T1ce on ET)
2. Quantitative morphology analysis (Area, Perimeter, Circularity, Eccentricity)
3. Failure analysis stratified by tumor size and slice position
4. Robustness curves across noise, blur, gamma, and intensity shifts
Saves all CSVs to results/ for 100% code-traceable reporting.
"""

import os
import sys
import numpy as np
import pandas as pd
from skimage.measure import regionprops, label
from skimage.filters import gaussian
from scipy.stats import pearsonr

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

from src.pipeline import run_pipeline, load_config
from src.loader import load_nifti_volume
from src.preprocessing import clip_percentiles, normalize_min_max, extract_axial_slice
from src.filtering import apply_median_filter
from src.enhancement import apply_clahe
from src.skull_stripping import extract_brain_mask
from src.segmentation_methods import segment_kmeans
from src.tumor_segmentation import morphological_tumor_cleanup
from src.metrics import dice_coefficient, iou_score, precision_score, recall_score


def get_morphology_props(mask: np.ndarray, voxel_spacing: float = 1.0):
    """
    Computes geometric properties of binary mask:
    - Area (mm^2)
    - Perimeter (mm)
    - Circularity: 4 * pi * Area / Perimeter^2 (1.0 for perfect circle)
    - Eccentricity: 0 for circle, approaches 1 for elongated ellipse
    """
    labeled = label(mask)
    if labeled.max() == 0:
        return {
            "area_mm2": 0.0,
            "perimeter_mm": 0.0,
            "circularity": 0.0,
            "eccentricity": 0.0
        }
    
    props = regionprops(labeled)
    # Get largest component for shape descriptors
    largest = max(props, key=lambda p: p.area)
    
    total_area_px = float(np.sum(mask))
    total_area_mm2 = total_area_px * (voxel_spacing ** 2)
    perim = float(largest.perimeter) * voxel_spacing
    
    if perim > 0:
        circ = float(4.0 * np.pi * largest.area / (perim ** 2))
        circ = min(1.0, max(0.0, circ))
    else:
        circ = 0.0
        
    ecc = float(largest.eccentricity)
    
    return {
        "area_mm2": total_area_mm2,
        "perimeter_mm": perim,
        "circularity": circ,
        "eccentricity": ecc
    }


def main():
    print("=" * 80)
    print("Computing Extended Experimental Results for IEEE Report")
    print("=" * 80)
    
    cfg = load_config()
    results_dir = os.path.join(PROJECT_ROOT, "results")
    slice_df = pd.read_csv(os.path.join(results_dir, "slice_list.csv"))
    test_slices = slice_df[slice_df["split"] == "TEST"].copy()
    
    r_open = cfg["baseline_tumor_segmentation"]["disk_r_open"]
    r_close = cfg["baseline_tumor_segmentation"]["disk_r_close"]
    min_comp_size = cfg["baseline_tumor_segmentation"]["min_component_size"]
    
    print(f"Loaded {len(test_slices)} TEST slices across {test_slices['patient'].nunique()} patients.")
    
    # -------------------------------------------------------------
    # 1. Failure Analysis from stage5_per_slice.csv
    # -------------------------------------------------------------
    print("\n[1/4] Computing Failure Analysis...")
    stage5_df = pd.read_csv(os.path.join(results_dir, "stage5_per_slice.csv"))
    test_k3 = stage5_df[(stage5_df["split"] == "TEST") & (stage5_df["method"] == "KMeans_K3")].copy()
    
    # Stratify by tumor size: Small (<1000), Medium (1000-3000), Large (>=3000)
    def size_category(area):
        if area < 1000:
            return "Small (<1000 px)"
        elif area <= 3000:
            return "Medium (1000-3000 px)"
        else:
            return "Large (>3000 px)"
            
    test_k3["size_cat"] = test_k3["gt_area"].apply(size_category)
    
    # Stratify by slice position: Inferior (slice < 55), Mid (55-95), Superior (>95)
    def position_category(s):
        if s < 55:
            return "Inferior (z < 55)"
        elif s <= 95:
            return "Mid-axial (55 <= z <= 95)"
        else:
            return "Superior (z > 95)"
            
    test_k3["pos_cat"] = test_k3["slice"].apply(position_category)
    
    failure_size = test_k3.groupby("size_cat").agg(
        count=("dice", "count"),
        dice_mean=("dice", "mean"),
        dice_std=("dice", "std"),
        iou_mean=("iou", "mean"),
        prec_mean=("precision", "mean"),
        rec_mean=("recall", "mean")
    ).reset_index()
    
    failure_pos = test_k3.groupby("pos_cat").agg(
        count=("dice", "count"),
        dice_mean=("dice", "mean"),
        dice_std=("dice", "std"),
        iou_mean=("iou", "mean"),
        prec_mean=("precision", "mean"),
        rec_mean=("recall", "mean")
    ).reset_index()
    
    failure_size.to_csv(os.path.join(results_dir, "failure_analysis_size.csv"), index=False)
    failure_pos.to_csv(os.path.join(results_dir, "failure_analysis_position.csv"), index=False)
    print("Saved failure_analysis_size.csv and failure_analysis_position.csv")
    
    # -------------------------------------------------------------
    # 2. Modality Comparison (FLAIR, T1, T1ce, T2 on WT, T1ce on ET)
    # -------------------------------------------------------------
    print("\n[2/4] Computing Multi-Modality Comparison on TEST Set...")
    modalities = ["flair", "t1", "t1ce", "t2"]
    modality_results = []
    
    # Run across test patients
    grouped = test_slices.groupby("patient")
    for patient_id, group in grouped:
        for _, row in group.iterrows():
            slice_idx = int(row["slice"])
            
            # Load ground truth segmentation
            pipe_flair = run_pipeline(patient_id, slice_idx, "flair", cfg)
            gt_wt = pipe_flair["gt_mask"]
            brain_mask = pipe_flair["brain_mask"]
            
            # Load ET ground truth (seg == 4)
            # Find patient dir
            from src.pipeline import resolve_patient_dir
            p_dir = resolve_patient_dir(patient_id, cfg)
            seg_vol, _ = load_nifti_volume(os.path.join(p_dir, f"{patient_id}_seg.nii"))
            gt_slice_raw = extract_axial_slice(seg_vol, slice_idx)
            gt_et = (gt_slice_raw == 4)
            
            for mod in modalities:
                if mod == "flair":
                    prep = pipe_flair["preprocessed_slice"]
                else:
                    pipe_mod = run_pipeline(patient_id, slice_idx, mod, cfg)
                    prep = pipe_mod["preprocessed_slice"]
                
                # Segment using K-Means (K=3)
                cand = segment_kmeans(prep, brain_mask, k=3, random_state=42)
                pred, _, _ = morphological_tumor_cleanup(cand, r_open, r_close, min_comp_size)
                
                # Evaluate vs WT
                d_wt = dice_coefficient(pred, gt_wt)
                iou_wt = iou_score(pred, gt_wt)
                p_wt = precision_score(pred, gt_wt)
                r_wt = recall_score(pred, gt_wt)
                
                res_entry = {
                    "patient": patient_id,
                    "slice": slice_idx,
                    "modality": mod,
                    "target": "Whole Tumor",
                    "dice": d_wt,
                    "iou": iou_wt,
                    "precision": p_wt,
                    "recall": r_wt
                }
                modality_results.append(res_entry)
                
                # If T1ce, also evaluate vs ET
                if mod == "t1ce":
                    d_et = dice_coefficient(pred, gt_et)
                    iou_et = iou_score(pred, gt_et)
                    p_et = precision_score(pred, gt_et)
                    r_et = recall_score(pred, gt_et)
                    modality_results.append({
                        "patient": patient_id,
                        "slice": slice_idx,
                        "modality": "t1ce_ET",
                        "target": "Enhancing Tumor",
                        "dice": d_et,
                        "iou": iou_et,
                        "precision": p_et,
                        "recall": r_et
                    })
                    
    mod_df = pd.DataFrame(modality_results)
    mod_df.to_csv(os.path.join(results_dir, "modality_per_slice.csv"), index=False)
    
    mod_summary = mod_df.groupby(["modality", "target"]).agg(
        dice_mean=("dice", "mean"),
        dice_std=("dice", "std"),
        iou_mean=("iou", "mean"),
        iou_std=("iou", "std"),
        precision_mean=("precision", "mean"),
        recall_mean=("recall", "mean")
    ).reset_index()
    mod_summary.to_csv(os.path.join(results_dir, "modality_comparison_summary.csv"), index=False)
    print("Saved modality_per_slice.csv and modality_comparison_summary.csv")
    
    # -------------------------------------------------------------
    # 3. Morphology Quantitative Analysis
    # -------------------------------------------------------------
    print("\n[3/4] Computing Morphological Quantitative Metrics...")
    morph_data = []
    
    for patient_id, group in grouped:
        for _, row in group.iterrows():
            slice_idx = int(row["slice"])
            pipe_flair = run_pipeline(patient_id, slice_idx, "flair", cfg)
            prep = pipe_flair["preprocessed_slice"]
            bmask = pipe_flair["brain_mask"]
            gt = pipe_flair["gt_mask"]
            
            cand = segment_kmeans(prep, bmask, k=3, random_state=42)
            pred, _, _ = morphological_tumor_cleanup(cand, r_open, r_close, min_comp_size)
            
            gt_props = get_morphology_props(gt, voxel_spacing=1.0)
            pred_props = get_morphology_props(pred, voxel_spacing=1.0)
            
            morph_data.append({
                "patient": patient_id,
                "slice": slice_idx,
                "gt_area_mm2": gt_props["area_mm2"],
                "pred_area_mm2": pred_props["area_mm2"],
                "gt_perimeter_mm": gt_props["perimeter_mm"],
                "pred_perimeter_mm": pred_props["perimeter_mm"],
                "gt_circularity": gt_props["circularity"],
                "pred_circularity": pred_props["circularity"],
                "gt_eccentricity": gt_props["eccentricity"],
                "pred_eccentricity": pred_props["eccentricity"]
            })
            
    morph_df = pd.DataFrame(morph_data)
    morph_df.to_csv(os.path.join(results_dir, "morphology_per_slice.csv"), index=False)
    
    # Summary error statistics: Mean, Std, Pearson r, MAPE
    def get_stat(gt_col, pred_col):
        gt_v = morph_df[gt_col].values
        pred_v = morph_df[pred_col].values
        abs_err = np.abs(pred_v - gt_v)
        mae = float(np.mean(abs_err))
        # Mask out zero gt for MAPE
        nonzero_idx = gt_v > 0
        mape = float(np.mean(abs_err[nonzero_idx] / gt_v[nonzero_idx]) * 100.0)
        corr, _ = pearsonr(gt_v, pred_v)
        return mae, mape, float(corr), float(np.mean(gt_v)), float(np.mean(pred_v))
        
    area_mae, area_mape, area_r, gt_area_m, pr_area_m = get_stat("gt_area_mm2", "pred_area_mm2")
    perim_mae, perim_mape, perim_r, gt_per_m, pr_per_m = get_stat("gt_perimeter_mm", "pred_perimeter_mm")
    circ_mae, circ_mape, circ_r, gt_circ_m, pr_circ_m = get_stat("gt_circularity", "pred_circularity")
    ecc_mae, ecc_mape, ecc_r, gt_ecc_m, pr_ecc_m = get_stat("gt_eccentricity", "pred_eccentricity")
    
    morph_summary = pd.DataFrame([
        {"feature": "Area (mm^2)", "gt_mean": gt_area_m, "pred_mean": pr_area_m, "mae": area_mae, "mape_percent": area_mape, "pearson_r": area_r},
        {"feature": "Perimeter (mm)", "gt_mean": gt_per_m, "pred_mean": pr_per_m, "mae": perim_mae, "mape_percent": perim_mape, "pearson_r": perim_r},
        {"feature": "Circularity", "gt_mean": gt_circ_m, "pred_mean": pr_circ_m, "mae": circ_mae, "mape_percent": circ_mape, "pearson_r": circ_r},
        {"feature": "Eccentricity", "gt_mean": gt_ecc_m, "pred_mean": pr_ecc_m, "mae": ecc_mae, "mape_percent": ecc_mape, "pearson_r": ecc_r}
    ])
    morph_summary.to_csv(os.path.join(results_dir, "morphology_summary.csv"), index=False)
    print("Saved morphology_per_slice.csv and morphology_summary.csv")
    
    # -------------------------------------------------------------
    # 4. Robustness Perturbation Curves
    # -------------------------------------------------------------
    print("\n[4/4] Computing Robustness Degradation Curves on TEST Set...")
    noise_sigmas = [0.0, 0.01, 0.02, 0.05, 0.10]
    blur_sigmas = [0.0, 0.5, 1.0, 1.5, 2.0]
    gammas = [0.6, 0.8, 1.0, 1.25, 1.6]
    intensity_shifts = [-0.10, -0.05, 0.0, 0.05, 0.10]
    
    robust_records = []
    
    # Pre-load clean slices to avoid re-reading
    cached_slices = []
    for patient_id, group in grouped:
        for _, row in group.iterrows():
            slice_idx = int(row["slice"])
            pipe = run_pipeline(patient_id, slice_idx, "flair", cfg)
            cached_slices.append({
                "patient": patient_id,
                "slice": slice_idx,
                "prep": pipe["preprocessed_slice"],
                "bmask": pipe["brain_mask"],
                "gt": pipe["gt_mask"]
            })
            
    np.random.seed(42)
    # 4a. Noise
    for sig in noise_sigmas:
        dices = []
        for item in cached_slices:
            prep = item["prep"].copy()
            bmask = item["bmask"]
            gt = item["gt"]
            if sig > 0.0:
                noise = np.random.normal(0, sig, prep.shape)
                prep = np.clip(prep + noise, 0.0, 1.0)
            cand = segment_kmeans(prep, bmask, k=3, random_state=42)
            pred, _, _ = morphological_tumor_cleanup(cand, r_open, r_close, min_comp_size)
            dices.append(dice_coefficient(pred, gt))
        robust_records.append({
            "perturbation_type": "Gaussian Noise",
            "parameter": "sigma",
            "value": sig,
            "dice_mean": float(np.mean(dices)),
            "dice_std": float(np.std(dices))
        })
        
    # 4b. Blur
    for sig in blur_sigmas:
        dices = []
        for item in cached_slices:
            prep = item["prep"].copy()
            bmask = item["bmask"]
            gt = item["gt"]
            if sig > 0.0:
                prep = gaussian(prep, sigma=sig, preserve_range=True)
            cand = segment_kmeans(prep, bmask, k=3, random_state=42)
            pred, _, _ = morphological_tumor_cleanup(cand, r_open, r_close, min_comp_size)
            dices.append(dice_coefficient(pred, gt))
        robust_records.append({
            "perturbation_type": "Gaussian Blur",
            "parameter": "sigma",
            "value": sig,
            "dice_mean": float(np.mean(dices)),
            "dice_std": float(np.std(dices))
        })
        
    # 4c. Gamma
    for gam in gammas:
        dices = []
        for item in cached_slices:
            prep = item["prep"].copy()
            bmask = item["bmask"]
            gt = item["gt"]
            if gam != 1.0:
                prep = np.power(np.clip(prep, 0.0, 1.0), gam)
            cand = segment_kmeans(prep, bmask, k=3, random_state=42)
            pred, _, _ = morphological_tumor_cleanup(cand, r_open, r_close, min_comp_size)
            dices.append(dice_coefficient(pred, gt))
        robust_records.append({
            "perturbation_type": "Gamma Contrast",
            "parameter": "gamma",
            "value": gam,
            "dice_mean": float(np.mean(dices)),
            "dice_std": float(np.std(dices))
        })
        
    # 4d. Intensity shift
    for delta in intensity_shifts:
        dices = []
        for item in cached_slices:
            prep = item["prep"].copy()
            bmask = item["bmask"]
            gt = item["gt"]
            if delta != 0.0:
                prep = np.clip(prep + delta, 0.0, 1.0)
            cand = segment_kmeans(prep, bmask, k=3, random_state=42)
            pred, _, _ = morphological_tumor_cleanup(cand, r_open, r_close, min_comp_size)
            dices.append(dice_coefficient(pred, gt))
        robust_records.append({
            "perturbation_type": "Intensity Shift",
            "parameter": "delta",
            "value": delta,
            "dice_mean": float(np.mean(dices)),
            "dice_std": float(np.std(dices))
        })
        
    robust_df = pd.DataFrame(robust_records)
    robust_df.to_csv(os.path.join(results_dir, "robustness_summary.csv"), index=False)
    print("Saved robustness_summary.csv")
    
    print("\nAll extended results successfully computed and saved to results/!")


if __name__ == "__main__":
    main()
