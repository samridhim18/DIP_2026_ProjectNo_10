import numpy as np
from skimage import exposure
from scipy.ndimage import sobel
from typing import Dict, Optional, Tuple, Any


def apply_histogram_equalization(image: np.ndarray, mask: Optional[np.ndarray] = None) -> np.ndarray:
    """
    Applies Global Histogram Equalization to enhance image dynamic range.
    Mask-aware: equalizes intensity distribution inside mask and forces background to 0.0.

    Parameters
    ----------
    image : np.ndarray
        2D input image slice (float32, normalized [0, 1]).
    mask : np.ndarray, optional
        Boolean mask array of foreground brain region.

    Returns
    -------
    equalized_image : np.ndarray
        Histogram equalized 2D image (float32, [0, 1]).
    """
    img_float = image.astype(np.float32)

    if mask is not None and np.any(mask):
        # Equalize using mask statistics and zero out background
        equalized = exposure.equalize_hist(img_float, mask=mask)
        equalized[~mask] = 0.0
    else:
        equalized = exposure.equalize_hist(img_float)

    return np.clip(equalized, 0.0, 1.0).astype(np.float32)


def apply_clahe(
    image: np.ndarray,
    clip_limit: float = 0.03,
    kernel_size: Optional[Tuple[int, int]] = (8, 8),
    mask: Optional[np.ndarray] = None
) -> np.ndarray:
    """
    Applies Contrast Limited Adaptive Histogram Equalization (CLAHE).
    Mask-aware: enhances local contrast and forces background outside mask to 0.0.

    Parameters
    ----------
    image : np.ndarray
        2D input image slice (float32, normalized [0, 1]).
    clip_limit : float, optional
        Clipping limit for local contrast amplification (default: 0.03).
    kernel_size : Tuple[int, int], optional
        Contextual tile grid size (default: (8, 8)).
    mask : np.ndarray, optional
        Boolean foreground brain mask.

    Returns
    -------
    clahe_image : np.ndarray
        CLAHE enhanced 2D image (float32, [0, 1]).
    """
    img_float = image.astype(np.float32)
    enhanced = exposure.equalize_adapthist(img_float, kernel_size=kernel_size, clip_limit=clip_limit)

    if mask is not None and np.any(mask):
        enhanced[~mask] = 0.0

    return np.clip(enhanced, 0.0, 1.0).astype(np.float32)


def compute_image_metrics(
    image: np.ndarray,
    mask: Optional[np.ndarray] = None,
    gt_seg_slice: Optional[np.ndarray] = None,
    num_bins: int = 256
) -> Dict[str, float]:
    """
    Calculates quantitative image quality statistics strictly over brain tissue:
      1. Mean Intensity (mu) inside brain mask
      2. Standard Deviation (sigma) inside brain mask
      3. Shannon Entropy (H = -sum(p * log2(p))) inside brain mask
      4. Mean Gradient Magnitude (Sobel edge strength) inside brain mask
      5. Tumor-vs-Normal Contrast: mean(tumor) - mean(non-tumor brain)
         (measured ONLY if ground truth slice is provided for evaluation)

    Parameters
    ----------
    image : np.ndarray
        2D image slice (float32, normalized [0, 1]).
    mask : np.ndarray, optional
        Boolean foreground brain mask (default: image > 0).
    gt_seg_slice : np.ndarray, optional
        Ground truth segmentation slice (seg > 0) used solely as a measurement mask.
    num_bins : int, optional
        Histogram bins for Shannon entropy calculation (default: 256).

    Returns
    -------
    metrics : Dict[str, float]
        Dictionary of computed quality metrics.
    """
    if mask is None:
        mask = image > 0

    if not np.any(mask):
        pixels = image.ravel()
    else:
        pixels = image[mask]

    mean_val = float(np.mean(pixels))
    std_val = float(np.std(pixels))

    # Shannon Entropy over normalized histogram inside brain mask
    hist, _ = np.histogram(pixels, bins=num_bins, range=(0.0, 1.0))
    prob = hist / np.sum(hist)
    prob_nz = prob[prob > 0]
    entropy_val = float(-np.sum(prob_nz * np.log2(prob_nz)))

    # Edge strength: Mean gradient magnitude inside brain mask using Sobel operator
    gx = sobel(image, axis=0)
    gy = sobel(image, axis=1)
    grad_mag = np.hypot(gx, gy)
    mean_grad = float(np.mean(grad_mag[mask])) if np.any(mask) else float(np.mean(grad_mag))

    metrics = {
        "mean": round(mean_val, 4),
        "std": round(std_val, 4),
        "entropy": round(entropy_val, 4),
        "mean_gradient": round(mean_grad, 4)
    }

    # Tumor-vs-normal contrast using ground truth ONLY as measuring mask
    if gt_seg_slice is not None:
        tumor_mask = np.logical_and(gt_seg_slice > 0, mask)
        normal_mask = np.logical_and(gt_seg_slice == 0, mask)

        if np.any(tumor_mask) and np.any(normal_mask):
            tumor_mean = float(np.mean(image[tumor_mask]))
            normal_mean = float(np.mean(image[normal_mask]))
            contrast_val = tumor_mean - normal_mean
            metrics["tumor_vs_normal_contrast"] = round(contrast_val, 4)
        else:
            metrics["tumor_vs_normal_contrast"] = 0.0

    return metrics
