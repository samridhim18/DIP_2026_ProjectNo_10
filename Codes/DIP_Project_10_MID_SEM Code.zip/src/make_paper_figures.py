"""
make_paper_figures.py
Generates publication-quality IEEE conference figures (white background,
black text, sans-serif font, 300 dpi, sized 3.5 in or 7.16 in, panels (a), (b), etc.)
strictly from CSV files and saved data in results/.
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib import rcParams

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

from src.pipeline import run_pipeline, load_config
from src.segmentation_methods import (
    segment_global_otsu,
    segment_multi_otsu,
    segment_kmeans
)
from src.tumor_segmentation import morphological_tumor_cleanup

# IEEE styling settings
rcParams['font.family'] = 'sans-serif'
rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial', 'Helvetica']
rcParams['font.size'] = 8.5
rcParams['axes.labelsize'] = 9.0
rcParams['axes.titlesize'] = 9.5
rcParams['xtick.labelsize'] = 8.0
rcParams['ytick.labelsize'] = 8.0
rcParams['legend.fontsize'] = 8.0
rcParams['figure.titlesize'] = 10.0
rcParams['figure.dpi'] = 300
rcParams['savefig.dpi'] = 300
rcParams['axes.edgecolor'] = 'black'
rcParams['axes.linewidth'] = 0.8
rcParams['text.color'] = 'black'
rcParams['axes.labelcolor'] = 'black'
rcParams['xtick.color'] = 'black'
rcParams['ytick.color'] = 'black'

FIGURES_DIR = os.path.join(PROJECT_ROOT, "Mid_Sem_Report", "figures")
os.makedirs(FIGURES_DIR, exist_ok=True)
RESULTS_DIR = os.path.join(PROJECT_ROOT, "results")


def make_fig1_pipeline_diagram():
    """
    Fig. 1: End-to-end DIP pipeline architecture block diagram (two columns, 7.16 in).
    """
    fig, ax = plt.subplots(figsize=(7.16, 2.7), facecolor='white')
    ax.set_facecolor('white')
    ax.axis('off')

    # Box styles
    box_props = dict(boxstyle='round,pad=0.35', facecolor='#F0F4F8', edgecolor='#1A365D', linewidth=1.2)
    accent_props = dict(boxstyle='round,pad=0.35', facecolor='#EBF8FF', edgecolor='#2B6CB0', linewidth=1.4)
    out_props = dict(boxstyle='round,pad=0.35', facecolor='#EDFDFD', edgecolor='#234E52', linewidth=1.4)

    # Stages data
    blocks = [
        ("Input FLAIR MRI\n(2D Slice $I$)", 0.08, 0.5, 0.12, 0.35, box_props),
        ("Stages 1 & 2: Preprocessing\nPercentile Clip [0.5, 99.5%]\nMedian Filter ($3\\times 3$)\nCLAHE (Grid $8\\times 8$)", 0.28, 0.5, 0.20, 0.65, accent_props),
        ("Stage 3: Brain Mask\nOtsu Intensity Threshold\nMorphological Closing ($r=3$)\nHole Fill + Max Comp.", 0.50, 0.5, 0.18, 0.65, accent_props),
        ("Stages 4 & 5: Segmentation\nIntensity K-Means ($K=3$)\nSelect Brightest Cluster\nInside Brain ROI", 0.72, 0.5, 0.18, 0.65, accent_props),
        ("Stage 6: Post-Processing\nOpening ($r=2$)\nClosing ($r=2$)\nArea Filter $\\geq 50$ px\nMorphology Measures", 0.92, 0.5, 0.16, 0.70, out_props),
    ]

    for title, xc, yc, w, h, props in blocks:
        ax.text(xc, yc, title, ha='center', va='center', fontsize=7.8,
                color='black', bbox=props)

    # Arrows between blocks
    arrows = [
        (0.13, 0.5, 0.16, 0.5),
        (0.34, 0.5, 0.39, 0.5),
        (0.57, 0.5, 0.62, 0.5),
        (0.80, 0.5, 0.85, 0.5),
    ]
    for x1, y1, x2, y2 in arrows:
        ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle="->,head_width=0.35,head_length=0.5",
                                    color='#2D3748', lw=1.5))

    ax.set_xlim(0, 1.02)
    ax.set_ylim(0.08, 0.92)
    
    out_path = os.path.join(FIGURES_DIR, "fig1_pipeline_architecture.png")
    plt.tight_layout()
    plt.savefig(out_path, dpi=300, facecolor='white')
    plt.close()
    print(f"Generated {out_path}")


def make_fig2_preprocessing_comparison():
    """
    Fig. 2: Qualitative comparison of preprocessing enhancements on slice 67 (two columns, 7.16 in).
    (a) Original FLAIR, (b) Median filtered, (c) CLAHE enhanced, (d) Histogram Equalization.
    """
    cfg = load_config()
    from src.loader import load_nifti_volume
    from src.preprocessing import clip_percentiles, normalize_min_max, extract_axial_slice
    from src.filtering import apply_median_filter
    from src.enhancement import apply_clahe, apply_histogram_equalization

    p_dir = os.path.join(PROJECT_ROOT)
    vol, _ = load_nifti_volume(os.path.join(p_dir, "BraTS20_Training_001_flair.nii"))
    raw_slice = extract_axial_slice(vol, 67)
    norm_slice = normalize_min_max(clip_percentiles(raw_slice, 0.5, 99.5))
    med_slice = apply_median_filter(norm_slice, size=3)
    clahe_slice = apply_clahe(med_slice, clip_limit=0.03, kernel_size=(8, 8))
    histeq_slice = apply_histogram_equalization(med_slice)

    fig, axes = plt.subplots(1, 4, figsize=(7.16, 2.2), facecolor='white')
    
    panels = [
        (norm_slice, "(a) Normalized FLAIR"),
        (med_slice, "(b) Median Filter ($3\\times 3$)"),
        (clahe_slice, "(c) CLAHE (Proposed)"),
        (histeq_slice, "(d) Global Hist. Eq.")
    ]

    for ax, (img, title) in zip(axes, panels):
        ax.set_facecolor('white')
        im = ax.imshow(img, cmap='gray', origin='lower')
        ax.set_title(title, fontsize=8.5, color='black', pad=4)
        ax.axis('off')

    plt.tight_layout()
    out_path = os.path.join(FIGURES_DIR, "fig2_preprocessing_comparison.png")
    plt.savefig(out_path, dpi=300, facecolor='white')
    plt.close()
    print(f"Generated {out_path}")


def make_fig3_method_comparison_boxplot():
    """
    Fig. 3: Boxplot of Dice Similarity Coefficient across 6 methods on TEST set (one column, 3.5 in).
    """
    df = pd.read_csv(os.path.join(RESULTS_DIR, "stage5_per_slice.csv"))
    test_df = df[df["split"] == "TEST"].copy()

    methods = [
        "Global_Otsu",
        "Multi_Otsu_3Class",
        "Adaptive_Local",
        "KMeans_K2",
        "KMeans_K3",
        "KMeans_K4"
    ]
    labels = [
        "Global Otsu",
        "Multi-Otsu (3C)",
        "Adaptive",
        "K-Means ($K=2$)",
        "K-Means ($K=3$)",
        "K-Means ($K=4$)"
    ]

    data = [test_df[test_df["method"] == m]["dice"].values for m in methods]

    fig, ax = plt.subplots(figsize=(3.5, 3.2), facecolor='white')
    ax.set_facecolor('white')

    # Color-blind safe palette (Okabe-Ito inspired)
    colors = ['#56B4E9', '#009E73', '#D55E00', '#CC79A7', '#0072B2', '#E69F00']

    bp = ax.boxplot(
        data,
        tick_labels=labels,
        patch_artist=True,
        showmeans=True,
        meanline=True,
        widths=0.6,
        medianprops=dict(color='black', linewidth=1.4),
        meanprops=dict(color='#D55E00', linewidth=1.2, linestyle='--'),
        flierprops=dict(marker='o', markersize=2.5, alpha=0.5, markerfacecolor='gray', markeredgecolor='none')
    )

    for patch, c in zip(bp['boxes'], colors):
        patch.set_facecolor(c)
        patch.set_alpha(0.75)
        patch.set_edgecolor('black')
        patch.set_linewidth(0.8)

    ax.set_ylabel("Dice Similarity Coefficient (DSC)", fontsize=8.5, color='black')
    ax.set_ylim(-0.05, 1.05)
    ax.grid(axis='y', linestyle=':', alpha=0.6, color='gray')
    ax.tick_params(axis='x', rotation=35, labelsize=7.5)
    ax.tick_params(axis='y', labelsize=8.0)

    # Custom legend for median and mean
    line_med = plt.Line2D([0], [0], color='black', lw=1.4, label='Median')
    line_mean = plt.Line2D([0], [0], color='#D55E00', lw=1.2, linestyle='--', label='Mean')
    ax.legend(handles=[line_med, line_mean], loc='lower right', frameon=True, facecolor='white', edgecolor='#CCCCCC')

    plt.tight_layout()
    out_path = os.path.join(FIGURES_DIR, "fig3_method_comparison_boxplot.png")
    plt.savefig(out_path, dpi=300, facecolor='white')
    plt.close()
    print(f"Generated {out_path}")


def make_fig4_qualitative_segmentation():
    """
    Fig. 4: Qualitative segmentation results on representative median slice (two columns, 7.16 in).
    Panels: (a) Preprocessed FLAIR, (b) Ground Truth, (c) Global Otsu, (d) Multi-Otsu, (e) K-Means (K=3), (f) Error Overlay.
    """
    cfg = load_config()
    patient_id = "BraTS20_Training_363"
    slice_idx = 74

    pipe = run_pipeline(patient_id, slice_idx, "flair", cfg)
    prep = pipe["preprocessed_slice"]
    bmask = pipe["brain_mask"]
    gt = pipe["gt_mask"]

    r_open = cfg["baseline_tumor_segmentation"]["disk_r_open"]
    r_close = cfg["baseline_tumor_segmentation"]["disk_r_close"]
    min_comp_size = cfg["baseline_tumor_segmentation"]["min_component_size"]

    c_otsu = segment_global_otsu(prep, bmask)
    p_otsu, _, _ = morphological_tumor_cleanup(c_otsu, r_open, r_close, min_comp_size)

    c_motsu = segment_multi_otsu(prep, bmask, classes=3)
    p_motsu, _, _ = morphological_tumor_cleanup(c_motsu, r_open, r_close, min_comp_size)

    c_k3 = segment_kmeans(prep, bmask, k=3, random_state=42)
    p_k3, _, _ = morphological_tumor_cleanup(c_k3, r_open, r_close, min_comp_size)

    # Error overlay RGB for K-Means (K=3)
    tp = np.logical_and(p_k3, gt)
    fp = np.logical_and(p_k3, ~gt)
    fn = np.logical_and(~p_k3, gt)

    overlay = np.dstack([prep, prep, prep])
    overlay[tp] = [0.0, 0.85, 0.2]   # Green = TP
    overlay[fp] = [0.95, 0.15, 0.15] # Red = FP
    overlay[fn] = [0.15, 0.35, 0.95] # Blue = FN

    fig, axes = plt.subplots(1, 6, figsize=(7.16, 1.8), facecolor='white')

    panels = [
        (prep, "gray", "(a) FLAIR"),
        (gt, "Greens", "(b) Ground Truth"),
        (p_otsu, "Blues", "(c) Global Otsu"),
        (p_motsu, "Oranges", "(d) Multi-Otsu"),
        (p_k3, "Purples", "(e) K-Means ($K=3$)"),
        (overlay, None, "(f) Error Overlay")
    ]

    for ax, (im_data, cmap, title) in zip(axes, panels):
        ax.set_facecolor('white')
        if cmap is None:
            ax.imshow(im_data, origin='lower')
        elif cmap == "gray":
            ax.imshow(im_data, cmap='gray', origin='lower')
        else:
            # Show on top of grayscale image
            ax.imshow(prep, cmap='gray', origin='lower')
            masked = np.ma.masked_where(~im_data, im_data)
            ax.imshow(masked, cmap=cmap, alpha=0.8, origin='lower')

        ax.set_title(title, fontsize=7.8, color='black', pad=3)
        ax.axis('off')

    plt.tight_layout()
    out_path = os.path.join(FIGURES_DIR, "fig4_qualitative_segmentation.png")
    plt.savefig(out_path, dpi=300, facecolor='white')
    plt.close()
    print(f"Generated {out_path}")


def make_fig5_morphology_and_failure():
    """
    Fig. 5: Morphological accuracy and failure mode analysis (two columns, 7.16 in).
    (a) Predicted vs. Ground Truth Tumor Area (mm^2) with y=x identity line.
    (b) Dice Coefficient vs. Ground Truth Tumor Area (px) showing small lesion failure modes.
    """
    morph_df = pd.read_csv(os.path.join(RESULTS_DIR, "morphology_per_slice.csv"))
    per_slice_df = pd.read_csv(os.path.join(RESULTS_DIR, "stage5_per_slice.csv"))
    test_k3 = per_slice_df[(per_slice_df["split"] == "TEST") & (per_slice_df["method"] == "KMeans_K3")]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.16, 2.7), facecolor='white')

    # Panel (a): Area scatter
    ax1.set_facecolor('white')
    gt_a = morph_df["gt_area_mm2"].values
    pr_a = morph_df["pred_area_mm2"].values

    ax1.scatter(gt_a, pr_a, color='#0072B2', alpha=0.65, edgecolors='none', s=24, label='TEST Slices ($N=150$)')
    max_val = max(np.max(gt_a), np.max(pr_a)) * 1.05
    ax1.plot([0, max_val], [0, max_val], 'r--', lw=1.2, label='Identity line ($y=x$)')
    ax1.set_xlabel("Ground Truth Tumor Area ($mm^2$)", fontsize=8.5, color='black')
    ax1.set_ylabel("Predicted Tumor Area ($mm^2$)", fontsize=8.5, color='black')
    ax1.set_title("(a) Tumor Area Estimation", fontsize=9.0, color='black')
    ax1.set_xlim(0, max_val)
    ax1.set_ylim(0, max_val)
    ax1.grid(True, linestyle=':', alpha=0.6, color='gray')
    ax1.legend(loc='upper left', frameon=True, facecolor='white', edgecolor='#CCCCCC')

    # Panel (b): Failure mode - Dice vs GT Area
    ax2.set_facecolor('white')
    gt_px = test_k3["gt_area"].values
    dices = test_k3["dice"].values

    # Stratified colors
    c_small = '#D55E00'  # Orange-red for small
    c_med = '#009E73'    # Green for med
    c_large = '#0072B2'  # Blue for large

    ax2.scatter(gt_px[gt_px < 1000], dices[gt_px < 1000], color=c_small, s=24, alpha=0.7, label='Small (<1000 px)')
    ax2.scatter(gt_px[(gt_px >= 1000) & (gt_px <= 3000)], dices[(gt_px >= 1000) & (gt_px <= 3000)], color=c_med, s=24, alpha=0.7, label='Medium (1000-3000 px)')
    ax2.scatter(gt_px[gt_px > 3000], dices[gt_px > 3000], color=c_large, s=24, alpha=0.7, label='Large (>3000 px)')

    ax2.axvline(1000, color='gray', linestyle=':', lw=1.0)
    ax2.axvline(3000, color='gray', linestyle=':', lw=1.0)

    ax2.set_xlabel("Ground Truth Tumor Area (Pixels)", fontsize=8.5, color='black')
    ax2.set_ylabel("Dice Similarity Coefficient (DSC)", fontsize=8.5, color='black')
    ax2.set_title("(b) Dice vs. Lesion Size (Failure Analysis)", fontsize=9.0, color='black')
    ax2.set_ylim(-0.05, 1.05)
    ax2.grid(True, linestyle=':', alpha=0.6, color='gray')
    ax2.legend(loc='lower right', frameon=True, facecolor='white', edgecolor='#CCCCCC')

    plt.tight_layout()
    out_path = os.path.join(FIGURES_DIR, "fig5_morphology_analysis.png")
    plt.savefig(out_path, dpi=300, facecolor='white')
    plt.close()
    print(f"Generated {out_path}")


def make_fig6_robustness_curves():
    """
    Fig. 6: Robustness degradation curves under 4 perturbations (two columns, 7.16 in).
    (a) Gaussian Noise, (b) Gaussian Blur, (c) Gamma Contrast, (d) Brightness Shift.
    """
    rob_df = pd.read_csv(os.path.join(RESULTS_DIR, "robustness_summary.csv"))

    fig, axes = plt.subplots(1, 4, figsize=(7.16, 2.3), facecolor='white')

    sub_configs = [
        ("Gaussian Noise", "sigma", "Noise Std Dev ($\\sigma$)", "(a) Additive Noise", 'o', '#0072B2'),
        ("Gaussian Blur", "sigma", "Filter Width ($\\sigma$, px)", "(b) Spatial Blur", 's', '#009E73'),
        ("Gamma Contrast", "gamma", "Gamma Exponent ($\\gamma$)", "(c) Contrast Power", '^', '#D55E00'),
        ("Intensity Shift", "delta", "Brightness Shift ($\\Delta$)", "(d) Brightness Offset", 'd', '#CC79A7')
    ]

    for ax, (ptype, param, xlabel, title, marker, color) in zip(axes, sub_configs):
        ax.set_facecolor('white')
        subset = rob_df[rob_df["perturbation_type"] == ptype]
        x_vals = subset["value"].values
        y_vals = subset["dice_mean"].values
        y_err = subset["dice_std"].values

        ax.plot(x_vals, y_vals, marker=marker, markersize=4.5, color=color, lw=1.4, linestyle='-', label='Mean DSC')
        ax.fill_between(x_vals, y_vals - 0.5 * y_err, y_vals + 0.5 * y_err, color=color, alpha=0.18)

        ax.set_xlabel(xlabel, fontsize=8.0, color='black')
        ax.set_ylabel("Dice (DSC)", fontsize=8.0, color='black')
        ax.set_title(title, fontsize=8.5, color='black', pad=4)
        ax.set_ylim(0.40, 0.75)
        ax.grid(True, linestyle=':', alpha=0.6, color='gray')

    plt.tight_layout()
    out_path = os.path.join(FIGURES_DIR, "fig6_robustness_curves.png")
    plt.savefig(out_path, dpi=300, facecolor='white')
    plt.close()
    print(f"Generated {out_path}")


def main():
    print("=" * 80)
    print("Rendering All Publication Figures for IEEE Conference Paper (White Background)")
    print("=" * 80)
    make_fig1_pipeline_diagram()
    make_fig2_preprocessing_comparison()
    make_fig3_method_comparison_boxplot()
    make_fig4_qualitative_segmentation()
    make_fig5_morphology_and_failure()
    make_fig6_robustness_curves()
    print("All 6 publication figures generated successfully in Mid_Sem_Report/figures/!")


if __name__ == "__main__":
    main()
