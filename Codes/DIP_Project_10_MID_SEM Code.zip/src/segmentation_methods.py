import numpy as np
from skimage.filters import threshold_otsu, threshold_multiotsu, threshold_local
from sklearn.cluster import KMeans
from typing import Tuple, Dict, Any, Optional


def segment_global_otsu(image: np.ndarray, brain_mask: np.ndarray) -> np.ndarray:
    """
    Method (a): Global Otsu thresholding computed inside brain mask.
    """
    brain_pixels = image[brain_mask]
    if len(brain_pixels) == 0:
        return np.zeros_like(image, dtype=bool)

    thresh = float(threshold_otsu(brain_pixels))
    candidate = np.logical_and(image > thresh, brain_mask)
    return candidate


def segment_multi_otsu(image: np.ndarray, brain_mask: np.ndarray, classes: int = 3) -> np.ndarray:
    """
    Method (b): Multilevel Otsu with 3 classes.
    Selects the highest intensity class (hyperintense core/edema).
    """
    brain_pixels = image[brain_mask]
    if len(brain_pixels) == 0:
        return np.zeros_like(image, dtype=bool)

    # If brain_pixels has too few unique values, fallback to single Otsu
    unique_vals = np.unique(brain_pixels)
    if len(unique_vals) < classes:
        thresh = float(threshold_otsu(brain_pixels))
        return np.logical_and(image > thresh, brain_mask)

    try:
        thresholds = threshold_multiotsu(brain_pixels, classes=classes)
        highest_thresh = float(thresholds[-1])
        candidate = np.logical_and(image > highest_thresh, brain_mask)
    except Exception:
        thresh = float(threshold_otsu(brain_pixels))
        candidate = np.logical_and(image > thresh, brain_mask)

    return candidate


def segment_adaptive_local(
    image: np.ndarray,
    brain_mask: np.ndarray,
    block_size: int = 31,
    offset: float = 0.0
) -> np.ndarray:
    """
    Method (c): Adaptive/Local thresholding using skimage threshold_local.
    Block size must be an odd integer.
    """
    if block_size % 2 == 0:
        block_size += 1

    local_thresh = threshold_local(image, block_size=block_size, offset=offset, method='gaussian', mode='reflect')
    candidate = np.logical_and(image > local_thresh, brain_mask)
    return candidate


def segment_kmeans(
    image: np.ndarray,
    brain_mask: np.ndarray,
    k: int = 3,
    random_state: int = 42
) -> np.ndarray:
    """
    Method (d): K-Means clustering on pixel intensities inside the brain mask.
    Rule without ground truth: Select the cluster with the highest mean intensity.
    """
    brain_coords = np.argwhere(brain_mask)
    if len(brain_coords) == 0:
        return np.zeros_like(image, dtype=bool)

    X = image[brain_mask].reshape(-1, 1).astype(np.float32)

    # If unique values < k, fallback to Otsu
    if len(np.unique(X)) < k:
        thresh = float(threshold_otsu(X))
        return np.logical_and(image > thresh, brain_mask)

    kmeans = KMeans(n_clusters=k, random_state=random_state, n_init=10).fit(X)
    centers = kmeans.cluster_centers_.ravel()
    brightest_cluster_idx = int(np.argmax(centers))

    candidate = np.zeros_like(image, dtype=bool)
    labels = kmeans.labels_
    brightest_pixel_mask = (labels == brightest_cluster_idx)

    # Assign True to pixels belonging to the brightest cluster
    candidate[brain_coords[brightest_pixel_mask, 0], brain_coords[brightest_pixel_mask, 1]] = True
    return candidate
