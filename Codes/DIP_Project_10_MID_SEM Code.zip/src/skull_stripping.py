import numpy as np
from scipy.ndimage import binary_fill_holes
from skimage.filters import threshold_otsu, threshold_triangle
from skimage.morphology import opening, closing, disk
from skimage.measure import label, regionprops
from typing import Tuple, Dict, Any, Optional


def apply_otsu_threshold(image: np.ndarray, method: str = "otsu") -> Tuple[np.ndarray, float]:
    """
    Computes automatic global threshold across the full 2D image to separate brain tissue from background air.

    Parameters
    ----------
    image : np.ndarray
        2D image slice (float32, normalized [0, 1]).
    method : str, optional
        Thresholding algorithm: 'otsu' or 'triangle' (default: 'otsu').

    Returns
    -------
    binary_mask : np.ndarray
        Boolean binary mask (True where image > threshold).
    thresh_val : float
        Calculated threshold value.
    """
    if method.lower() == "triangle":
        thresh_val = float(threshold_triangle(image))
    else:
        thresh_val = float(threshold_otsu(image))

    binary_mask = image > thresh_val
    return binary_mask, thresh_val


def extract_brain_mask(
    image: np.ndarray,
    disk_radius: int = 3,
    min_size: int = 1000,
    thresh_method: str = "otsu"
) -> Tuple[np.ndarray, Dict[str, np.ndarray], Dict[str, Any]]:
    """
    Executes the classical 5-stage skull stripping and brain mask extraction pipeline:
      Stage 1: Intensity Thresholding (Otsu / Triangle)
      Stage 2: Binary Morphological Cleanup (Opening with circular disk)
      Stage 3: Hole Filling (Ventricles, Necrotic Core & Edema Cavities)
      Stage 4: Connected Component Analysis & Largest Region Selection
      Stage 5: Final Morphological Contour Smoothing (Closing)

    Parameters
    ----------
    image : np.ndarray
        Preprocessed 2D image slice (float32, [0, 1]).
    disk_radius : int, optional
        Radius of circular structuring element for morphological operations (default: 3).
    min_size : int, optional
        Minimum component pixel size to consider (default: 1000).
    thresh_method : str, optional
        Thresholding algorithm ('otsu' or 'triangle', default: 'otsu').

    Returns
    -------
    final_brain_mask : np.ndarray
        Boolean binary brain mask.
    intermediate_masks : Dict[str, np.ndarray]
        Dictionary storing intermediate pipeline binary masks for visualization.
    pipeline_info : Dict[str, Any]
        Dictionary containing threshold value and component stats.
    """
    selem = disk(disk_radius)

    # 1. Intensity Thresholding across full 2D slice
    initial_mask, thresh_val = apply_otsu_threshold(image, method=thresh_method)

    # 2. Binary Morphological Cleanup (Opening severs narrow anatomical bridges to skull/dura)
    cleaned_mask = opening(initial_mask, selem)

    # 3. Hole Filling (Encloses internal ventricles, hypointense core, edema)
    filled_mask = binary_fill_holes(cleaned_mask)

    # 4. Connected-Component Analysis & Largest Component Selection
    labeled_img, num_features = label(filled_mask, return_num=True)
    largest_component_mask = np.zeros_like(filled_mask, dtype=bool)

    if num_features > 0:
        regions = regionprops(labeled_img)
        # Filter and sort regions by area descending
        regions.sort(key=lambda r: r.area, reverse=True)
        largest_label = regions[0].label
        largest_component_mask = (labeled_img == largest_label)

    # 5. Final Morphological Smoothing (Closing smooths outer cortical margin)
    final_brain_mask = closing(largest_component_mask, selem)

    # Re-apply binary_fill_holes to guarantee no internal holes remain
    final_brain_mask = binary_fill_holes(final_brain_mask)

    intermediate_masks = {
        "initial": initial_mask,
        "cleaned": cleaned_mask,
        "filled": filled_mask,
        "largest_component": largest_component_mask,
        "final_brain_mask": final_brain_mask,
    }

    pipeline_info = {
        "otsu_threshold": round(thresh_val, 4),
        "thresh_method": thresh_method,
        "num_connected_components": num_features,
        "brain_area_pixels": int(np.sum(final_brain_mask)),
    }

    return final_brain_mask, intermediate_masks, pipeline_info


def apply_brain_mask(image: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """
    Applies binary brain mask to isolate brain tissue from background/skull.

    Parameters
    ----------
    image : np.ndarray
        2D image slice.
    mask : np.ndarray
        Boolean binary mask.

    Returns
    -------
    skull_stripped_image : np.ndarray
        Masked image with non-brain voxels set to 0.0.
    """
    return np.where(mask, image, 0.0).astype(image.dtype)


def compute_mask_statistics(
    brain_mask: np.ndarray,
    ground_truth_mask: Optional[np.ndarray] = None
) -> Dict[str, Any]:
    """
    Calculates quantitative metrics for extracted brain mask:
      - Brain area in pixels
      - Percentage of 2D slice occupied by brain mask
      - Sørensen–Dice coefficient & Jaccard IoU (if reference mask available)

    Parameters
    ----------
    brain_mask : np.ndarray
        Extracted binary brain mask (boolean array).
    ground_truth_mask : np.ndarray, optional
        Reference segmentation mask or brain region mask.

    Returns
    -------
    stats : Dict[str, Any]
        Dictionary of mask area, coverage percentage, Dice, and Jaccard metrics.
    """
    total_pixels = brain_mask.size
    brain_pixels = int(np.sum(brain_mask))
    percentage = (brain_pixels / total_pixels) * 100.0

    stats = {
        "total_pixels": total_pixels,
        "brain_area_pixels": brain_pixels,
        "percentage_occupied": round(percentage, 2),
    }

    if ground_truth_mask is not None:
        gt_bool = ground_truth_mask > 0
        intersection = np.logical_and(brain_mask, gt_bool)
        union = np.logical_or(brain_mask, gt_bool)
        
        intersection_count = int(np.sum(intersection))
        union_count = int(np.sum(union))
        brain_count = int(np.sum(brain_mask))
        gt_count = int(np.sum(gt_bool))

        dice = (2.0 * intersection_count) / (brain_count + gt_count) if (brain_count + gt_count) > 0 else 1.0
        jaccard = (intersection_count / union_count) if union_count > 0 else 1.0

        stats["dice_coefficient"] = round(float(dice), 4)
        stats["jaccard_iou"] = round(float(jaccard), 4)

    return stats
