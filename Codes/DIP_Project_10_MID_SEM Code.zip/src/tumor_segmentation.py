import numpy as np
from skimage.filters import threshold_otsu
from skimage.morphology import opening, closing, disk
from skimage.measure import label, regionprops
from typing import Tuple, Dict, Any, List


def otsu_brain_threshold(skull_stripped_image: np.ndarray, brain_mask: np.ndarray) -> Tuple[np.ndarray, float]:
    """
    Applies Otsu thresholding strictly inside the brain ROI to extract hyperintense tumor candidate pixels.

    Parameters
    ----------
    skull_stripped_image : np.ndarray
        2D skull-stripped MRI slice (float32, [0, 1]).
    brain_mask : np.ndarray
        Boolean binary brain mask.

    Returns
    -------
    candidate_mask : np.ndarray
        Initial binary tumor candidate mask (boolean array).
    thresh_val : float
        Calculated Otsu threshold value inside brain ROI.
    """
    brain_pixels = skull_stripped_image[brain_mask]
    
    if len(brain_pixels) == 0:
        return np.zeros_like(skull_stripped_image, dtype=bool), 0.0

    thresh_val = float(threshold_otsu(brain_pixels))
    candidate_mask = np.logical_and(skull_stripped_image > thresh_val, brain_mask)
    return candidate_mask, thresh_val


def morphological_tumor_cleanup(
    candidate_mask: np.ndarray,
    disk_r_open: int = 2,
    disk_r_close: int = 2,
    min_size: int = 50
) -> Tuple[np.ndarray, List[Any], Dict[str, Any]]:
    """
    Applies classical morphological opening, closing, and connected-component filtering to clean tumor candidate mask.

    Parameters
    ----------
    candidate_mask : np.ndarray
        Initial binary candidate mask.
    disk_r_open : int, optional
        Radius of circular disk for morphological opening (default: 2).
    disk_r_close : int, optional
        Radius of circular disk for morphological closing (default: 2).
    min_size : int, optional
        Minimum area in pixels to retain a connected component (default: 50).

    Returns
    -------
    cleaned_mask : np.ndarray
        Morphologically cleaned binary tumor mask.
    valid_regions : List[Any]
        List of retained region properties.
    cleanup_info : Dict[str, Any]
        Information summary on components filtered and retained.
    """
    # 1. Morphological Opening (removes small isolated noise spikes)
    opened = opening(candidate_mask, disk(disk_r_open))

    # 2. Morphological Closing (connects nearby tumor sub-regions)
    closed = closing(opened, disk(disk_r_close))

    # 3. Connected-Component Analysis
    labeled_img, total_components = label(closed, return_num=True)
    cleaned_mask = np.zeros_like(closed, dtype=bool)
    valid_regions = []

    if total_components > 0:
        regions = regionprops(labeled_img)
        for r in regions:
            if r.area >= min_size:
                cleaned_mask[labeled_img == r.label] = True
                valid_regions.append({
                    "label": r.label,
                    "area": r.area,
                    "centroid": (round(r.centroid[0], 2), round(r.centroid[1], 2)),
                    "bbox": r.bbox
                })

    cleanup_info = {
        "initial_candidate_pixels": int(np.sum(candidate_mask)),
        "total_connected_components": total_components,
        "retained_components": len(valid_regions),
        "final_tumor_pixels": int(np.sum(cleaned_mask))
    }

    return cleaned_mask, valid_regions, cleanup_info


def evaluate_segmentation(pred_mask: np.ndarray, gt_mask: np.ndarray) -> Dict[str, Any]:
    """
    Calculates standard quantitative segmentation evaluation metrics:
      - Sørensen-Dice Coefficient
      - Jaccard Index (IoU)
      - Predicted vs Ground-Truth Tumor Areas
      - Confusion Matrix Maps (TP, FP, FN)

    Parameters
    ----------
    pred_mask : np.ndarray
        Predicted binary tumor mask.
    gt_mask : np.ndarray
        Ground-truth segmentation mask (labels > 0).

    Returns
    -------
    metrics : Dict[str, Any]
        Dictionary of quantitative evaluation metrics and confusion maps.
    """
    pred_bool = pred_mask > 0
    gt_bool = gt_mask > 0

    tp = np.logical_and(pred_bool, gt_bool)
    fp = np.logical_and(pred_bool, np.logical_not(gt_bool))
    fn = np.logical_and(np.logical_not(pred_bool), gt_bool)
    tn = np.logical_and(np.logical_not(pred_bool), np.logical_not(gt_bool))

    tp_count = int(np.sum(tp))
    fp_count = int(np.sum(fp))
    fn_count = int(np.sum(fn))
    tn_count = int(np.sum(tn))

    pred_area = int(np.sum(pred_bool))
    gt_area = int(np.sum(gt_bool))

    dice = (2.0 * tp_count) / (pred_area + gt_area) if (pred_area + gt_area) > 0 else 1.0
    union_count = tp_count + fp_count + fn_count
    iou = (tp_count / union_count) if union_count > 0 else 1.0

    area_diff = pred_area - gt_area
    pct_diff = (area_diff / gt_area * 100.0) if gt_area > 0 else 0.0

    return {
        "predicted_area_px": pred_area,
        "ground_truth_area_px": gt_area,
        "area_difference_px": area_diff,
        "percentage_difference": round(pct_diff, 2),
        "tp_count": tp_count,
        "fp_count": fp_count,
        "fn_count": fn_count,
        "dice": round(float(dice), 4),
        "iou": round(float(iou), 4),
        "tp_map": tp,
        "fp_map": fp,
        "fn_map": fn
    }
