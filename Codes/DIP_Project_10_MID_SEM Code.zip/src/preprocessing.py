import numpy as np
from typing import Tuple, Optional


def normalize_min_max(volume: np.ndarray, feature_range: Tuple[float, float] = (0.0, 1.0)) -> np.ndarray:
    """
    Applies Min-Max linear scaling to map MRI intensity values into a target range [a, b].

    Formula:
        I_norm = a + (I - min(I)) * (b - a) / (max(I) - min(I))

    Parameters
    ----------
    volume : np.ndarray
        Raw 3D MRI volume array.
    feature_range : Tuple[float, float], optional
        Target intensity range (default: (0.0, 1.0)).

    Returns
    -------
    normalized_volume : np.ndarray
        Min-max normalized 3D array (float32).
    """
    v_min = np.min(volume)
    v_max = np.max(volume)
    target_min, target_max = feature_range

    if np.isclose(v_max, v_min):
        return np.zeros_like(volume, dtype=np.float32)

    normalized = (volume - v_min) / (v_max - v_min)
    normalized = target_min + normalized * (target_max - target_min)
    return normalized.astype(np.float32)


def normalize_z_score(volume: np.ndarray, mask_zero_bg: bool = True) -> np.ndarray:
    """
    Standardizes MRI intensity values to zero mean and unit variance.

    Formula:
        I_z = (I - mean) / std

    Parameters
    ----------
    volume : np.ndarray
        Raw 3D MRI volume.
    mask_zero_bg : bool, optional
        If True, only non-zero voxel intensities (brain region) are used to calculate
        the mean and standard deviation, leaving background voxels as 0.0 (default: True).

    Returns
    -------
    z_scored_volume : np.ndarray
        Z-score normalized 3D array (float32).
    """
    vol_float = volume.astype(np.float32)

    if mask_zero_bg:
        brain_mask = vol_float > 0
        if not np.any(brain_mask):
            return np.zeros_like(vol_float)
        mean_val = np.mean(vol_float[brain_mask])
        std_val = np.std(vol_float[brain_mask])
        
        normalized = np.zeros_like(vol_float)
        if std_val > 1e-6:
            normalized[brain_mask] = (vol_float[brain_mask] - mean_val) / std_val
        return normalized
    else:
        mean_val = np.mean(vol_float)
        std_val = np.std(vol_float)
        if std_val > 1e-6:
            return (vol_float - mean_val) / std_val
        return np.zeros_like(vol_float)


def clip_percentiles(volume: np.ndarray, p_low: float = 0.5, p_high: float = 99.5) -> np.ndarray:
    """
    Clips extreme MRI intensity outliers to specified percentiles to reduce noise spikes.

    Parameters
    ----------
    volume : np.ndarray
        Input MRI volume.
    p_low : float, optional
        Lower percentile threshold (default: 0.5).
    p_high : float, optional
        Upper percentile threshold (default: 99.5).

    Returns
    -------
    clipped_volume : np.ndarray
        Percentile clipped 3D volume.
    """
    non_zero_voxels = volume[volume > 0]
    if len(non_zero_voxels) == 0:
        return volume.copy()

    low_val = np.percentile(non_zero_voxels, p_low)
    high_val = np.percentile(non_zero_voxels, p_high)
    return np.clip(volume, low_val, high_val)


def extract_axial_slice(volume: np.ndarray, slice_idx: int) -> np.ndarray:
    """
    Extracts a 2D axial (Z-axis) slice from a 3D volume (shape: H x W x D).

    Parameters
    ----------
    volume : np.ndarray
        3D array of shape (X, Y, Z).
    slice_idx : int
        Index along Z axis (0 <= slice_idx < Z).

    Returns
    -------
    slice_2d : np.ndarray
        2D axial slice oriented correctly for visualization.
    """
    num_slices = volume.shape[2]
    if not (0 <= slice_idx < num_slices):
        raise ValueError(f"Slice index {slice_idx} out of range [0, {num_slices - 1}]")

    # Extract 2D slice: volume[:, :, slice_idx]
    # Rotate 90 deg counter-clockwise so anterior is top and right is right
    slice_2d = np.rot90(volume[:, :, slice_idx])
    return slice_2d


def find_best_slice(mask_volume: np.ndarray) -> Tuple[int, int]:
    """
    Finds the axial slice index containing the maximum number of non-zero tumor voxels.

    Parameters
    ----------
    mask_volume : np.ndarray
        3D segmentation mask volume.

    Returns
    -------
    best_slice_idx : int
        Slice index with the highest tumor voxel count.
    max_count : int
        Count of tumor voxels in that slice.
    """
    num_slices = mask_volume.shape[2]
    counts = [np.count_nonzero(mask_volume[:, :, z]) for z in range(num_slices)]
    best_slice_idx = int(np.argmax(counts))
    max_count = int(counts[best_slice_idx])
    return best_slice_idx, max_count
