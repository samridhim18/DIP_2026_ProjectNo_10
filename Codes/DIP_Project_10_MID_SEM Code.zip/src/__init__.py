"""
BraTS MRI Classical Image Processing Package.
Contains dataset loading, preprocessing, normalization, and visualization utilities.
"""

__version__ = "1.0.0"
