import numpy as np
from typing import Dict, Any, Optional, Tuple


def dice_coefficient(y_pred: np.ndarray, y_true: np.ndarray) -> float:
    """
    Computes the Sørensen-Dice coefficient between prediction and ground truth.
    Safely handles edge cases with empty masks without division by zero.

    Formula:
        Dice = 2 * |P ∩ G| / (|P| + |G|)
    """
    pred_bool = np.asarray(y_pred, dtype=bool)
    true_bool = np.asarray(y_true, dtype=bool)

    pred_sum = int(np.sum(pred_bool))
    true_sum = int(np.sum(true_bool))

    if pred_sum == 0 and true_sum == 0:
        return 1.0  # Both empty: perfect agreement on negative class
    if pred_sum == 0 or true_sum == 0:
        return 0.0  # One empty, one non-empty: complete disagreement

    intersection = int(np.sum(np.logical_and(pred_bool, true_bool)))
    return float((2.0 * intersection) / (pred_sum + true_sum))


def iou_score(y_pred: np.ndarray, y_true: np.ndarray) -> float:
    """
    Computes the Intersection over Union (Jaccard Index).
    Safely handles edge cases with empty masks without division by zero.

    Formula:
        IoU = |P ∩ G| / |P ∪ G|
    """
    pred_bool = np.asarray(y_pred, dtype=bool)
    true_bool = np.asarray(y_true, dtype=bool)

    pred_sum = int(np.sum(pred_bool))
    true_sum = int(np.sum(true_bool))

    if pred_sum == 0 and true_sum == 0:
        return 1.0
    if pred_sum == 0 or true_sum == 0:
        return 0.0

    intersection = int(np.sum(np.logical_and(pred_bool, true_bool)))
    union = int(np.sum(np.logical_or(pred_bool, true_bool)))
    return float(intersection / union)


def precision_score(y_pred: np.ndarray, y_true: np.ndarray) -> float:
    """
    Computes Precision (Positive Predictive Value): TP / (TP + FP).
    """
    pred_bool = np.asarray(y_pred, dtype=bool)
    true_bool = np.asarray(y_true, dtype=bool)

    tp = int(np.sum(np.logical_and(pred_bool, true_bool)))
    fp = int(np.sum(np.logical_and(pred_bool, ~true_bool)))

    if tp + fp == 0:
        fn = int(np.sum(np.logical_and(~pred_bool, true_bool)))
        return 1.0 if fn == 0 else 0.0

    return float(tp / (tp + fp))


def recall_score(y_pred: np.ndarray, y_true: np.ndarray) -> float:
    """
    Computes Recall (Sensitivity / True Positive Rate): TP / (TP + FN).
    """
    pred_bool = np.asarray(y_pred, dtype=bool)
    true_bool = np.asarray(y_true, dtype=bool)

    tp = int(np.sum(np.logical_and(pred_bool, true_bool)))
    fn = int(np.sum(np.logical_and(~pred_bool, true_bool)))

    if tp + fn == 0:
        fp = int(np.sum(np.logical_and(pred_bool, ~true_bool)))
        return 1.0 if fp == 0 else 0.0

    return float(tp / (tp + fn))


def area_error_percent(y_pred: np.ndarray, y_true: np.ndarray) -> float:
    """
    Computes relative area error percentage: (|P| - |G|) / |G| * 100.
    """
    pred_bool = np.asarray(y_pred, dtype=bool)
    true_bool = np.asarray(y_true, dtype=bool)

    pred_area = int(np.sum(pred_bool))
    gt_area = int(np.sum(true_bool))

    if gt_area == 0:
        return 0.0 if pred_area == 0 else 100.0

    return float(((pred_area - gt_area) / gt_area) * 100.0)


def confusion_matrix_counts(y_pred: np.ndarray, y_true: np.ndarray) -> Dict[str, int]:
    """
    Computes TP, FP, FN, TN counts for binary segmentation masks.
    """
    pred_bool = np.asarray(y_pred, dtype=bool)
    true_bool = np.asarray(y_true, dtype=bool)

    tp = int(np.sum(np.logical_and(pred_bool, true_bool)))
    fp = int(np.sum(np.logical_and(pred_bool, ~true_bool)))
    fn = int(np.sum(np.logical_and(~pred_bool, true_bool)))
    tn = int(np.sum(np.logical_and(~pred_bool, ~true_bool)))

    return {"tp": tp, "fp": fp, "fn": fn, "tn": tn}


def compute_all_metrics(
    y_pred: np.ndarray,
    y_true: np.ndarray,
    voxel_spacing: Optional[Tuple[float, ...]] = None
) -> Dict[str, Any]:
    """
    Computes complete quantitative evaluation metrics dictionary.
    Includes physical area in mm² if 2D voxel spacing (dx, dy) is provided.
    """
    pred_bool = np.asarray(y_pred, dtype=bool)
    true_bool = np.asarray(y_true, dtype=bool)

    cm = confusion_matrix_counts(pred_bool, true_bool)
    pred_area = int(np.sum(pred_bool))
    gt_area = int(np.sum(true_bool))

    metrics = {
        "dice": round(dice_coefficient(pred_bool, true_bool), 4),
        "iou": round(iou_score(pred_bool, true_bool), 4),
        "precision": round(precision_score(pred_bool, true_bool), 4),
        "recall": round(recall_score(pred_bool, true_bool), 4),
        "area_error_percent": round(area_error_percent(pred_bool, true_bool), 2),
        "pred_area_px": pred_area,
        "gt_area_px": gt_area,
        "area_diff_px": pred_area - gt_area,
        "tp": cm["tp"],
        "fp": cm["fp"],
        "fn": cm["fn"],
        "tn": cm["tn"]
    }

    if voxel_spacing is not None and len(voxel_spacing) >= 2:
        pixel_area_mm2 = float(voxel_spacing[0] * voxel_spacing[1])
        metrics["pixel_area_mm2"] = pixel_area_mm2
        metrics["pred_area_mm2"] = round(pred_area * pixel_area_mm2, 2)
        metrics["gt_area_mm2"] = round(gt_area * pixel_area_mm2, 2)
        metrics["area_diff_mm2"] = round((pred_area - gt_area) * pixel_area_mm2, 2)

    return metrics
