import os
import yaml
import numpy as np
import nibabel as nib
from typing import Dict, Any, Optional, Tuple

from src.loader import load_nifti_volume
from src.preprocessing import clip_percentiles, normalize_min_max, extract_axial_slice
from src.filtering import apply_median_filter, apply_gaussian_filter
from src.enhancement import apply_clahe, apply_histogram_equalization
from src.skull_stripping import extract_brain_mask, apply_brain_mask
from src.tumor_segmentation import otsu_brain_threshold, morphological_tumor_cleanup
from src.metrics import compute_all_metrics


def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Loads pipeline configuration YAML file.
    """
    if config_path is None:
        # Default config path relative to project root
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        config_path = os.path.join(base_dir, "src", "config.yaml")

    with open(config_path, "r") as f:
        cfg = yaml.safe_load(f)
    return cfg


def resolve_patient_dir(patient_id: str, cfg: Optional[Dict[str, Any]] = None) -> str:
    """
    Locates patient directory across local project folder and dataset archive.
    """
    if cfg is None:
        cfg = load_config()

    local_root = cfg["data"]["local_root"]
    local_patient_dir = os.path.join(local_root, patient_id)
    if os.path.isdir(local_patient_dir):
        return local_patient_dir

    archive_root = cfg["data"]["dataset_root"]
    archive_patient_dir = os.path.join(archive_root, patient_id)
    if os.path.isdir(archive_patient_dir):
        return archive_patient_dir

    raise FileNotFoundError(f"Patient directory not found for {patient_id} in {local_root} or {archive_root}")


def run_pipeline(
    patient_id: str,
    slice_idx: int,
    modality: str = "flair",
    cfg: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Runs end-to-end classical DIP tumor segmentation pipeline for any patient and slice.

    Parameters
    ----------
    patient_id : str
        e.g. 'BraTS20_Training_001'
    slice_idx : int
        Axial slice index (0 to 154)
    modality : str, optional
        MRI modality ('flair', 't1', 't1ce', 't2', default: 'flair')
    cfg : Dict[str, Any], optional
        Config dictionary from src/config.yaml

    Returns
    -------
    result : Dict[str, Any]
        Dictionary containing preprocessed slices, masks, and computed metrics.
    """
    if cfg is None:
        cfg = load_config()

    # 1. Resolve patient directory and file paths
    patient_dir = resolve_patient_dir(patient_id, cfg)
    modality_file = os.path.join(patient_dir, f"{patient_id}_{modality.lower()}.nii")
    seg_file = os.path.join(patient_dir, f"{patient_id}_seg.nii")

    if not os.path.exists(modality_file):
        raise FileNotFoundError(f"Modality file not found: {modality_file}")
    if not os.path.exists(seg_file):
        raise FileNotFoundError(f"Segmentation ground-truth file not found: {seg_file}")

    # 2. Load 3D volumes
    mod_vol, mod_nifti = load_nifti_volume(modality_file)
    seg_vol, _ = load_nifti_volume(seg_file)

    # Voxel spacing from NIfTI header (dx, dy, dz)
    header = mod_nifti.header
    voxel_spacing = tuple(round(float(v), 3) for v in header.get_zooms()[:3])

    # 3. Extract 2D axial slice
    raw_slice = extract_axial_slice(mod_vol, slice_idx)
    seg_slice = extract_axial_slice(seg_vol, slice_idx)
    gt_mask = seg_slice > 0

    # 4. Normalization
    p_low = cfg["preprocessing"]["percentile_clip"]["p_low"]
    p_high = cfg["preprocessing"]["percentile_clip"]["p_high"]
    clipped_slice = clip_percentiles(raw_slice, p_low=p_low, p_high=p_high)
    norm_slice = normalize_min_max(clipped_slice)
    initial_brain_mask = norm_slice > 0

    # 5. Preprocessing (Median filtering + Mask-aware CLAHE)
    median_size = cfg["preprocessing"]["median"]["size"]
    clahe_clip = cfg["preprocessing"]["clahe"]["clip_limit"]
    clahe_tile = tuple(cfg["preprocessing"]["clahe"]["tile_grid_size"])

    med_slice = apply_median_filter(norm_slice, size=median_size)
    med_slice[~initial_brain_mask] = 0.0

    preprocessed_slice = apply_clahe(med_slice, clip_limit=clahe_clip, kernel_size=clahe_tile, mask=initial_brain_mask)

    # 6. Brain Mask / Skull Stripping
    strip_disk = cfg["skull_stripping"]["disk_radius"]
    strip_min_size = cfg["skull_stripping"]["min_component_size"]
    strip_thresh_method = cfg["skull_stripping"]["threshold_method"]

    final_brain_mask, _, strip_info = extract_brain_mask(
        preprocessed_slice,
        disk_radius=strip_disk,
        min_size=strip_min_size,
        thresh_method=strip_thresh_method
    )
    skull_stripped_slice = apply_brain_mask(preprocessed_slice, final_brain_mask)

    # 7. Baseline Tumor Candidate Generation
    candidate_mask, otsu_thresh = otsu_brain_threshold(skull_stripped_slice, final_brain_mask)

    # 8. Morphological Cleanup & Component Analysis
    r_open = cfg["baseline_tumor_segmentation"]["disk_r_open"]
    r_close = cfg["baseline_tumor_segmentation"]["disk_r_close"]
    min_comp_size = cfg["baseline_tumor_segmentation"]["min_component_size"]

    final_mask, valid_components, cleanup_info = morphological_tumor_cleanup(
        candidate_mask,
        disk_r_open=r_open,
        disk_r_close=r_close,
        min_size=min_comp_size
    )

    # 9. Quantitative Evaluation against ground truth
    metrics = compute_all_metrics(final_mask, gt_mask, voxel_spacing=voxel_spacing[:2])

    return {
        "patient_id": patient_id,
        "slice_idx": slice_idx,
        "modality": modality,
        "voxel_spacing": voxel_spacing,
        "raw_slice": raw_slice,
        "norm_slice": norm_slice,
        "preprocessed_slice": preprocessed_slice,
        "brain_mask": final_brain_mask,
        "skull_stripped_slice": skull_stripped_slice,
        "candidate_mask": candidate_mask,
        "final_mask": final_mask,
        "gt_mask": gt_mask,
        "metrics": metrics,
        "otsu_thresh": round(otsu_thresh, 4),
        "valid_components": valid_components,
        "cleanup_info": cleanup_info,
        "strip_info": strip_info
    }
