import os
import nibabel as nib
import numpy as np
from typing import Tuple, Dict, Any, Optional


def load_nifti_volume(filepath: str, dtype: np.dtype = np.float32) -> Tuple[np.ndarray, nib.Nifti1Image]:
    """
    Loads a NIfTI MRI or segmentation file (.nii / .nii.gz) using Nibabel.

    Parameters
    ----------
    filepath : str
        Path to the NIfTI file.
    dtype : np.dtype, optional
        Target numpy data type for intensity values (default: np.float32).

    Returns
    -------
    volume_data : np.ndarray
        3D numpy array representing the MRI or mask volume.
    nifti_img : nib.Nifti1Image
        The raw nibabel NIfTI image object containing headers and spatial affine.

    Raises
    ------
    FileNotFoundError
        If the NIfTI file does not exist at the specified path.
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"NIfTI file not found: {filepath}")

    nifti_img = nib.load(filepath)
    # get_fdata() loads image array and converts to float
    volume_data = np.asarray(nifti_img.get_fdata(), dtype=dtype)
    return volume_data, nifti_img


def get_volume_info(volume: np.ndarray, nifti_img: nib.Nifti1Image, filepath: str, is_mask: bool = False) -> Dict[str, Any]:
    """
    Inspects 3D volume dimensions, voxel spacing, datatype, and intensity distribution.

    Parameters
    ----------
    volume : np.ndarray
        3D numpy array of MRI volume or segmentation mask.
    nifti_img : nib.Nifti1Image
        Nibabel object associated with the volume.
    filepath : str
        Path to source file.
    is_mask : bool, optional
        Whether the volume represents a segmentation mask (default: False).

    Returns
    -------
    info : Dict[str, Any]
        Dictionary of shape dimensions, voxel spacing, and intensity statistics.
    """
    header = nifti_img.header
    voxel_spacing = header.get_zooms()[:3]  # (dx, dy, dz) in mm
    total_voxels = volume.size
    nonzero_voxels = np.count_nonzero(volume)
    nonzero_pct = (nonzero_voxels / total_voxels) * 100.0

    info = {
        "filepath": os.path.abspath(filepath),
        "shape": volume.shape,
        "voxel_spacing": tuple(round(float(v), 3) for v in voxel_spacing),
        "dtype": volume.dtype,
        "min_intensity": float(np.min(volume)),
        "max_intensity": float(np.max(volume)),
        "mean_intensity": float(np.mean(volume)),
        "std_intensity": float(np.std(volume)),
        "total_voxels": total_voxels,
        "nonzero_voxels": int(nonzero_voxels),
        "nonzero_percentage": round(nonzero_pct, 2),
        "affine": nifti_img.affine,
    }

    if is_mask:
        unique_labels, counts = np.unique(volume.astype(np.int32), return_counts=True)
        info["unique_labels"] = unique_labels.tolist()
        info["label_counts"] = dict(zip(unique_labels.tolist(), counts.tolist()))

    return info
