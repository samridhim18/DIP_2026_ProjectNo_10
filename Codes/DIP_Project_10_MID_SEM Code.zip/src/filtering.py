import numpy as np
from scipy.ndimage import gaussian_filter, median_filter
from typing import Optional


def apply_gaussian_filter(image: np.ndarray, sigma: float = 1.0) -> np.ndarray:
    """
    Applies 2D Gaussian spatial smoothing filter to an MRI slice.

    Formula:
        G(x, y) = (1 / (2 * pi * sigma^2)) * exp(-(x^2 + y^2) / (2 * sigma^2))

    Parameters
    ----------
    image : np.ndarray
        2D input image slice (float32, normalized [0, 1]).
    sigma : float, optional
        Standard deviation for Gaussian kernel (default: 1.0).

    Returns
    -------
    filtered_image : np.ndarray
        Gaussian smoothed 2D image (float32).
    """
    img_float = image.astype(np.float32)
    filtered = gaussian_filter(img_float, sigma=sigma, mode='reflect')
    return np.clip(filtered, 0.0, 1.0).astype(np.float32)


def apply_median_filter(image: np.ndarray, size: int = 3) -> np.ndarray:
    """
    Applies 2D Median non-linear rank filter to suppress noise while preserving sharp edges.

    Parameters
    ----------
    image : np.ndarray
        2D input image slice (float32, normalized [0, 1]).
    size : int, optional
        Window size of the median kernel (default: 3). Must be an odd integer.

    Returns
    -------
    filtered_image : np.ndarray
        Median filtered 2D image (float32).
    """
    if size % 2 == 0:
        raise ValueError(f"Kernel size must be an odd integer, got {size}")

    img_float = image.astype(np.float32)
    filtered = median_filter(img_float, size=size, mode='reflect')
    return np.clip(filtered, 0.0, 1.0).astype(np.float32)
