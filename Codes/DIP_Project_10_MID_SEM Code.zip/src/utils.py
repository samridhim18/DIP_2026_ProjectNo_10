import os
from typing import Dict, Any


def ensure_dir(path: str) -> str:
    """
    Ensures that a directory path exists. Creates it if missing.

    Parameters
    ----------
    path : str
        Directory path to create.

    Returns
    -------
    str
        Absolute path of created directory.
    """
    abs_path = os.path.abspath(path)
    os.makedirs(abs_path, exist_ok=True)
    return abs_path


def print_volume_summary(volume_name: str, info: Dict[str, Any]) -> None:
    """
    Pretty prints NIfTI 3D volume metadata summary to stdout.

    Parameters
    ----------
    volume_name : str
        Descriptive name of the volume (e.g. 'FLAIR MRI', 'Segmentation Mask').
    info : Dict[str, Any]
        Metadata dictionary output from src.loader.get_volume_info.
    """
    border = "=" * 60
    print(border)
    print(f" VOLUME SUMMARY: {volume_name.upper()}")
    print(border)
    print(f" File Path          : {info['filepath']}")
    print(f" Spatial Shape      : {info['shape']} (X x Y x Z / Sagittal x Coronal x Axial)")
    print(f" Voxel Spacing (mm) : {info['voxel_spacing']}")
    print(f" Data Type          : {info['dtype']}")
    print(f" Intensity Min      : {info['min_intensity']:.4f}")
    print(f" Intensity Max      : {info['max_intensity']:.4f}")
    print(f" Intensity Mean     : {info['mean_intensity']:.4f}")
    print(f" Intensity Std      : {info['std_intensity']:.4f}")
    print(f" Total Voxels       : {info['total_voxels']:,}")
    print(f" Non-zero Voxels    : {info['nonzero_voxels']:,} ({info['nonzero_percentage']:.2f}%)")
    
    if "unique_labels" in info:
        print(f" Unique Mask Labels : {info['unique_labels']}")
        print(f" Label Counts       : {info['label_counts']}")
    print(border + "\n")
