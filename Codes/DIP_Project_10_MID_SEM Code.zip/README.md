# Brain MRI Tumor Segmentation and Quantitative Analysis Using Classical Image Processing
### ECE 501: Digital Image Processing | Group 10
**Ahmedabad University, School of Engineering and Applied Science**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![Classical DIP](https://img.shields.io/badge/Method-Classical%20DIP%20(No%20DL)-success.svg)]()
[![Repository](https://img.shields.io/badge/GitHub-DIP__2026__ProjectNo__10-blue)](https://github.com/samridhim18/DIP_2026_ProjectNo_10)

---

## 👥 Project Team Members

| Name | Role | Enrollment Number | Affiliation |
| :--- | :--- | :--- | :--- |
| **Samridhi Mehrotra** | Team Leader | `AU2440033` | Ahmedabad University |
| **Maitri Lad** | Team Member | `AU2440146` | Ahmedabad University |
| **Kensi Patel** | Team Member | `AU2440102` | Ahmedabad University |
| **Sharanya Gupta** | Team Member | `AU2440048` | Ahmedabad University |

**GitHub Repository:** [https://github.com/samridhim18/DIP_2026_ProjectNo_10](https://github.com/samridhim18/DIP_2026_ProjectNo_10)

---

## 📌 Project Overview

This project implements an **explainable, deterministic, classical Digital Image Processing (DIP)** framework for whole-tumor segmentation and quantitative morphological shape analysis in multimodal brain MRI scans from the **BraTS 2020** benchmark dataset.

### Core Philosophy
* **Pure Classical DIP:** Strictly **NO** deep learning, convolutional neural networks (CNNs), U-Nets, transfer learning, or black-box machine learning classifiers.
* **Deterministic & Explainable:** Every stage relies on mathematical image transforms, intensity thresholding, spatial filtering, and mathematical morphology.
* **100% Code-Traceable:** No manually typed or invented numbers. Every reported metric, table value, and figure is programmatically derived from reproducible Python scripts and CSV data records.
* **Zero Ground-Truth Leakage:** Ground-truth annotations (`seg`) are strictly utilized for post-segmentation evaluation and slice selection, never for parameter tuning or cluster assignment.

---

## 🏗️ Pipeline Architecture

```
Input Multimodal MRI (FLAIR / T2 / T1ce / T1)
                     │
                     ▼
[Stage 1 & 2: Preprocessing & Contrast Enhancement]
   - Percentile Intensity Clipping [0.5%, 99.5%]
   - Min-Max Dynamic Range Normalization [0.0, 1.0]
   - Spatial Median Filtering (3x3 window) for noise suppression
   - Contrast-Limited Adaptive Histogram Equalization (CLAHE) (Grid 8x8, clip=0.03)
                     │
                     ▼
[Stage 3: Intracranial Brain Mask Extraction]
   - Global Otsu Intensity Thresholding on Cerebral Tissue
   - Morphological Closing (disk r=3) to bridge perimeter gaps
   - Binary Hole Filling (binary_fill_holes)
   - Largest Connected-Component Extraction (area >= 1000 px)
                     │
                     ▼
[Stages 4 & 5: Classical Segmentation Formulations]
   - (a) Global Otsu Thresholding within Brain ROI
   - (b) Multilevel Otsu with 3 Classes (highest-intensity tier)
   - (c) Adaptive Local Gaussian Thresholding (block_size=15, offset=-0.02)
   - (d) Unsupervised K-Means Intensity Clustering (K in {2, 3, 4})
         [Automated brightest-centroid cluster selection rule]
                     │
                     ▼
[Stage 6: Morphological Post-Processing Cleanup]
   - Binary Opening (disk r=2) to sever fine noise spurs
   - Binary Closing (disk r=2) to seal internal lacunae
   - 8-Connected Component Filtering (retains components >= 50 px)
                     │
                     ▼
[Quantitative Evaluation & Radiomic Morphology Extraction]
   - Overlap Metrics: Dice (DSC), Jaccard (IoU), Precision, Recall
   - Hypothesis Testing: Non-parametric Wilcoxon Signed-Rank Test
   - Shape Descriptors: Area (mm²), Perimeter (mm), Circularity, Eccentricity
   - Perturbation Stress Testing: Gaussian noise, blur, gamma, brightness shifts
```

---

## 📂 Codebase Directory Structure

```
.
├── main.py                          # Master Unified CLI Runner for all stages & tasks
├── stage2_preprocessing.py          # Stage 2 Preprocessing & quantitative contrast script
├── stage3_skull_stripping.py        # Stage 3 Intracranial brain mask extraction script
├── stage4_baseline_segmentation.py  # Stage 4 Baseline Otsu segmentation script
├── run_stage5_evaluation.py         # Stage 5 Master 20-patient benchmark evaluation
├── requirements.txt                 # Python package dependencies
├── README.md                        # Project documentation (this file)
│
├── src/                             # Core modular DIP library
│   ├── __init__.py
│   ├── config.yaml                  # Central configuration file for all pipeline parameters
│   ├── loader.py                    # NIfTI volume loader & header metadata inspector
│   ├── preprocessing.py             # Percentile clipping, min-max, z-score, axial slicing
│   ├── filtering.py                 # Spatial Gaussian & Median 2D filters
│   ├── enhancement.py               # CLAHE, global histogram equalization, entropy & edge strength
│   ├── skull_stripping.py           # Brain mask extraction, closing, hole filling, largest component
│   ├── segmentation_methods.py      # Global Otsu, Multi-Otsu, Adaptive Local, K-Means clustering
│   ├── tumor_segmentation.py        # Morphological opening/closing, component filter, regionprops
│   ├── metrics.py                   # Dice, IoU, Precision, Recall, confusion matrix, area error
│   ├── pipeline.py                  # End-to-end modular pipeline runner function
│   ├── compute_extended_results.py  # Extended experiments: failure analysis, modality, morphology, robustness
│   ├── make_paper_figures.py        # Publication figures generator (300 dpi, white background)
│   ├── generate_latex_numbers.py    # Auto-generates numbers.tex and LaTeX table files from CSVs
│   ├── visualization.py             # Plotting utilities for qualitative inspection
│   └── utils.py                     # Path utilities, directory creation, summary printers
│
├── tests/                           # Unit and integration test suite
│   ├── test_metrics.py              # Tests for Dice, IoU, precision, recall, area error
│   └── test_pipeline.py             # Tests for normalization, filters, brain mask, and segmentation
│
├── results/                         # Code-generated CSVs, logs, and summary reports
│   ├── slice_list.csv               # 20-patient benchmark slice cohort (50 DEV, 150 TEST)
│   ├── stage5_per_slice.csv         # Per-slice metrics across all 6 methods (1,200 evaluations)
│   ├── stage5_test_metrics.csv      # TEST split performance summary with Wilcoxon p-values
│   ├── stage5_dev_metrics.csv       # DEV split performance summary
│   ├── adaptive_tuning_grid.csv     # Grid search parameter sweep for Adaptive Local thresholding
│   ├── modality_comparison_summary.csv # Cross-modality comparison (FLAIR, T1, T1ce, T2, ET)
│   ├── morphology_summary.csv       # Shape feature accuracy (Area, Perimeter, Circularity, Eccentricity)
│   ├── failure_analysis_size.csv    # Performance stratified by lesion size (<1000, 1000-3000, >3000 px)
│   ├── failure_analysis_position.csv# Performance stratified by axial slice position (inferior, mid, superior)
│   ├── robustness_summary.csv       # Degradation curves under noise, blur, gamma, intensity shifts
│   └── audit_report.md              # Empirical skull-stripping audit documentation
│
├── Mid_Sem_Report/                  # Complete IEEE Conference Paper in LaTeX
│   ├── main.tex                     # Master IEEE paper source file
│   ├── IEEEtran.cls                 # Official IEEE conference LaTeX class file
│   ├── numbers.tex                  # Auto-generated LaTeX macros for all numerical results
│   ├── table1_parameters.tex        # Table I: Hyperparameter configurations
│   ├── table2_preprocessing.tex     # Table II: Preprocessing metrics
│   ├── table3_methods.tex           # Table III: Method comparison on TEST set
│   ├── table4_modalities.tex        # Table IV: Multi-modality comparison
│   ├── traceability.md              # Exhaustive mapping linking paper to underlying code & CSVs
│   └── figures/                     # Publication figures (white background, 300 dpi)
│       ├── fig1_pipeline_architecture.png
│       ├── fig2_preprocessing_comparison.png
│       ├── fig3_method_comparison_boxplot.png
│       ├── fig4_qualitative_segmentation.png
│       ├── fig5_morphology_analysis.png
│       └── fig6_robustness_curves.png
│
└── Mid_Sem_Report.zip               # Self-contained bundle ready for Overleaf compilation
```

---

## 🚀 Installation & Quickstart

### 1. Prerequisites
* Python 3.10 or higher (compatible with Conda / Miniforge / venv)
* Git

### 2. Clone Repository & Install Dependencies
```bash
git clone https://github.com/samridhim18/DIP_2026_ProjectNo_10.git
cd DIP_2026_ProjectNo_10

pip install -r requirements.txt
```

### 3. Verify Test Suite
Run the automated test suite to ensure all algorithms and metric calculations pass:
```bash
python -m unittest discover tests/
```
*(All 11 tests should report `OK` in under 0.1 seconds).*

---

## 💻 How to Run the Code

The master entry point is `main.py`, which provides a clean CLI interface for all operations.

### Run Individual Pipeline Stages
```bash
# Stage 1: Load NIfTI volume, volume inspection, normalize intensities, and save overlay
python main.py --stage 1

# Stage 2: Spatial filtering, CLAHE, histogram equalization, and contrast metrics
python main.py --stage 2

# Stage 3: Intracranial brain mask extraction, hole filling, and largest component
python main.py --stage 3

# Stage 4: Baseline Otsu segmentation within brain ROI on slice 67
python main.py --stage 4

# Stage 5: Method comparison on slice 67 (Otsu, Multi-Otsu, Adaptive, K-Means)
python main.py --stage 5

# Run all stages (1 through 5) sequentially
python main.py --stage all
```

### Run Custom Single-Slice Inference
Segment any patient, slice, or modality using any classical method:
```bash
# Run proposed K-Means (K=3) on Patient 001 Slice 67 (FLAIR)
python main.py --segment --patient BraTS20_Training_001 --slice 67 --modality flair --method kmeans3

# Run Multi-Otsu on Patient 001 Slice 67
python main.py --segment --patient BraTS20_Training_001 --slice 67 --method multiotsu

# Run on T1ce contrast-enhanced volume
python main.py --segment --patient BraTS20_Training_001 --slice 67 --modality t1ce --method kmeans3
```

### Reproduce Full Research Benchmark & Reports
```bash
# 1. Execute the full 20-patient / 200-slice Stage 5 benchmark (DEV & TEST with Wilcoxon tests)
python main.py --evaluate-benchmark

# 2. Run extended experiments (Failure analysis, Modality, Morphology, Robustness)
python main.py --extended-results

# 3. Generate all 6 publication figures at 300 dpi with white backgrounds
python main.py --make-figures

# 4. Generate numbers.tex and LaTeX table files directly from results/ CSVs
python main.py --generate-latex
```

---

## 📊 Summary of Main Experimental Findings

### 1. Segmentation Method Comparison on TEST Split ($N=150$ slices, 15 patients)
Evaluated across 15 unseen patients with non-parametric **Wilcoxon signed-rank** hypothesis testing vs. baseline Global Otsu:

| Method | Mean DSC | Median DSC | Mean IoU | Precision | Recall | Wilcoxon $p$-value |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Global Otsu (Baseline)** | 0.4859 | 0.4181 | 0.3858 | 0.4257 | **0.8817** | --- |
| **Multi-Otsu (3 Classes)** | 0.5811 | **0.6508** | 0.4461 | 0.6412 | 0.6840 | $5.36 \times 10^{-7}$ |
| **Adaptive Local Gaussian** | 0.2838 | 0.2747 | 0.1725 | 0.3058 | 0.3641 | $5.85 \times 10^{-13}$ |
| **K-Means ($K=2$)** | 0.4875 | 0.4217 | 0.3867 | 0.4288 | 0.8784 | $1.98 \times 10^{-7}$ |
| **K-Means ($K=3$, Selected)** | **0.5815** | 0.6492 | **0.4461** | 0.6449 | 0.6802 | **$7.94 \times 10^{-7}$** |
| **K-Means ($K=4$)** | 0.5659 | 0.6009 | 0.4245 | **0.7889** | 0.5101 | $3.78 \times 10^{-3}$ |

### 2. Failure Mode Analysis
* **Lesion Size Dependency:**
  * *Medium lesions ($1000-3000$ px):* Mean DSC is **$0.7049 \pm 0.1400$**.
  * *Large lesions ($>3000$ px):* Mean DSC is **$0.6672 \pm 0.0819$**.
  * *Small lesions ($<1000$ px):* Drops to **$0.4034 \pm 0.2451$** due to normal physiological hyperintensities confusing global intensity clustering.
* **Slice Position:**
  * *Superior slices ($z > 95$):* Mean DSC **$0.6281$** (high precision $0.7574$).
  * *Inferior slices ($z < 55$):* Drops to **$0.4227$** due to skull-base partial volume artifacts.

### 3. Multi-Modality Comparison
* **Whole Tumor (WT):** FLAIR ($0.5815$) $\gg$ T2 ($0.3855$) $\gg$ T1ce ($0.0987$) $\gg$ T1 ($0.0480$).
* **Enhancing Tumor (ET):** T1ce yields DSC $0.1872$ when evaluated against active angiogenic tumor core ($\text{seg} == 4$).

### 4. Quantitative Radiomic Morphology
* **Eccentricity ($e$):** Exceptionally strong estimation accuracy with **Pearson $r = 0.6100$** and **$17.13\%$ Mean Absolute Percentage Error (MAPE)**.
* **Area ($mm^2$):** MAE $967.41\text{ mm}^2$ (ground truth mean $1426.06\text{ mm}^2$).

### 5. Algorithmic Robustness Stress Testing
* **Additive Gaussian Noise:** Immune to severe noise up to $\sigma = 0.10$ (DSC maintained at $0.5815$).
* **Spatial Blur:** Smoothing up to $\sigma = 2.0$ improves contiguous clustering (DSC rises to $0.6124$).
* **Global Intensity Shift:** Inherently invariant across $\Delta \in [-0.10, +0.10]$ due to percentile clipping min-max normalization.

---

## 🔍 Scientific Audit Note on Skull Stripping

Prior to pipeline design, an empirical anatomical audit of the BraTS 2020 training volumes was performed:
* Exactly **84.96%** of 3D volume voxels and **70.39%** of axial slice 67 pixels have intensity strictly equal to $0.0$, with outer margins clamped to zero.
* **Conclusion:** The BraTS 2020 dataset was **already skull-stripped** by the challenge creators prior to release.
* Therefore, Stage 3 in our framework operates as **intracranial brain mask extraction and spatial regularization** (isolating the cerebral tissue ROI from background padding and sealing internal ventricles), rather than physical craniotomy/bone removal.

---

## 📄 IEEE Conference Paper & Overleaf Submission

The complete mid-semester report has been authored in LaTeX conforming strictly to the **IEEE Conference Two-Column format**:
* Location: `Mid_Sem_Report/main.tex`
* Auto-generated macros: `Mid_Sem_Report/numbers.tex`
* Traceability documentation: `Mid_Sem_Report/traceability.md`
* Standalone Overleaf Zip: [`Mid_Sem_Report.zip`](Mid_Sem_Report.zip) (Ready for direct upload to [Overleaf](https://www.overleaf.com)).

---

## 📜 License
This project is developed for educational and academic research purposes under the **ECE501 Digital Image Processing** course at Ahmedabad University.
