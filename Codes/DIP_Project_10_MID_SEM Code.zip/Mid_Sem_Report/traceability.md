# Data and Metric Traceability Matrix
## ECE501 Digital Image Processing (Group 10) Mid-Semester Report

This document provides a comprehensive traceability mapping linking every table, figure, and numerical finding in `Mid_Sem_Report/main.tex` to its exact generating Python script and backing CSV/data record in `results/`. No number in the paper is manually typed or estimated.

---

## 1. Figures Traceability

| Paper Figure | Figure File Path | Generating Script & Function | Primary Data Source(s) in `results/` | Description |
| :--- | :--- | :--- | :--- | :--- |
| **Fig. 1** | `Mid_Sem_Report/figures/fig1_pipeline_architecture.png` | `src/make_paper_figures.py` :: `make_fig1_pipeline_diagram()` | `src/config.yaml` | End-to-end Classical DIP Pipeline Architecture (Input $\to$ Normalization $\to$ Filtering/CLAHE $\to$ Brain Mask ROI $\to$ K-Means Clustering $\to$ Morphological Post-Processing $\to$ Evaluation). |
| **Fig. 2** | `Mid_Sem_Report/figures/fig2_preprocessing_comparison.png` | `src/make_paper_figures.py` :: `make_fig2_preprocessing_comparison()` | `BraTS20_Training_001_flair.nii` (Slice 67), `results/stage2_metrics_summary.txt` | Visual comparison of Stage 2 enhancement methods: (a) Normalized FLAIR, (b) Median filtered, (c) CLAHE (Proposed), (d) Global Histogram Equalization. |
| **Fig. 3** | `Mid_Sem_Report/figures/fig3_method_comparison_boxplot.png` | `src/make_paper_figures.py` :: `make_fig3_method_comparison_boxplot()` | `results/stage5_per_slice.csv` (`split == 'TEST'`, $N=150$ slices) | Boxplot distribution of Dice Similarity Coefficients (DSC) across all six classical segmentation algorithms on the unseen TEST cohort. |
| **Fig. 4** | `Mid_Sem_Report/figures/fig4_qualitative_segmentation.png` | `src/make_paper_figures.py` :: `make_fig4_qualitative_segmentation()` | `results/slice_list.csv`, `BraTS20_Training_363` (Slice 74) | Qualitative whole-tumor segmentations and RGB error overlay (TP green, FP red, FN blue) on representative median slice 74. |
| **Fig. 5** | `Mid_Sem_Report/figures/fig5_morphology_analysis.png` | `src/make_paper_figures.py` :: `make_fig5_morphology_and_failure()` | `results/morphology_per_slice.csv`, `results/stage5_per_slice.csv` | (a) Predicted vs. Ground Truth Whole-Tumor Area ($mm^2$) against identity line ($y=x$); (b) DSC vs. Ground Truth Tumor Area (pixels) illustrating small-lesion failure modes. |
| **Fig. 6** | `Mid_Sem_Report/figures/fig6_robustness_curves.png` | `src/make_paper_figures.py` :: `make_fig6_robustness_curves()` | `results/robustness_summary.csv` | Algorithmic robustness degradation curves under (a) Additive Gaussian Noise, (b) Spatial Gaussian Blur, (c) Gamma Contrast Distortion, and (d) Global Brightness Shifts. |

---

## 2. Tables Traceability

| Paper Table | LaTeX Snippet Path | Generating Script | Primary Data Source(s) in `results/` | Key Findings / Values Reported |
| :--- | :--- | :--- | :--- | :--- |
| **Table I** | `Mid_Sem_Report/table1_parameters.tex` | `src/generate_latex_numbers.py` | `src/config.yaml` | Hyperparameter configurations: Percentile clipping $[0.5\%, 99.5\%]$, median filter $3\times 3$, CLAHE grid $8\times 8$, clip limit $0.03$, brain mask radius $r=3$, opening/closing radii $r=2$, minimum lesion size $50$ px. |
| **Table II** | `Mid_Sem_Report/table2_preprocessing.tex` | `src/generate_latex_numbers.py` | `results/stage2_metrics_summary.txt` | Preprocessing quality on slice 67: Original (Entropy: 7.4205, Edge: 0.4027), Median (Entropy: 7.3023, Edge: 0.3125), CLAHE (Entropy: 7.6975, Edge: 0.7794). |
| **Table III** | `Mid_Sem_Report/table3_methods.tex` | `src/generate_latex_numbers.py` | `results/stage5_test_metrics.csv` | Segmentation performance on TEST split ($N=150$): Global Otsu (DSC 0.4859), Multi-Otsu (DSC 0.5811, $p=5.36\times 10^{-7}$), Adaptive (DSC 0.2838, $p=5.85\times 10^{-13}$), KMeans-2 (DSC 0.4875, $p=1.98\times 10^{-7}$), KMeans-3 (DSC 0.5815, $p=7.94\times 10^{-7}$), KMeans-4 (DSC 0.5659, $p=3.78\times 10^{-3}$). |
| **Table IV** | `Mid_Sem_Report/table4_modalities.tex` | `src/generate_latex_numbers.py` | `results/modality_comparison_summary.csv` | Multi-modality performance on TEST split ($N=150$): FLAIR WT (DSC 0.5815), T2 WT (DSC 0.3855), T1ce WT (DSC 0.0987), T1 WT (DSC 0.0480), T1ce ET (DSC 0.1872). |

---

## 3. Macro Numbers Traceability (`Mid_Sem_Report/numbers.tex`)

All in-text numerical statistics are mapped via LaTeX `\newcommand` macros in `Mid_Sem_Report/numbers.tex`.

### 3.1. Dataset and Protocol Cohort
| LaTeX Macro | Value | Source File | Description |
| :--- | :--- | :--- | :--- |
| `\TotalSlices` | `200` | `results/slice_list.csv` | Total benchmark axial slices |
| `\DevSlices` | `50` | `results/slice_list.csv` | Slices in Development partition (5 patients $\times$ 10 slices) |
| `\TestSlices` | `150` | `results/slice_list.csv` | Slices in Test partition (15 patients $\times$ 10 slices) |
| `\TotalPatients` | `20` | `results/slice_list.csv` | Total independent patients sampled from BraTS 2020 |
| `\MinTumorAreaThreshold` | `200` | `src/config.yaml` | Minimum ground-truth lesion area threshold for slice inclusion |
| `\AuditVolumeZeroPercent` | `84.96%` | `results/audit_report.md` | Proportion of voxels in 3D volume strictly equal to 0.0 |
| `\AuditSliceZeroPercent` | `70.39%` | `results/audit_report.md` | Proportion of pixels in axial slice 67 strictly equal to 0.0 |

### 3.2. Segmentation Performance on TEST Partition ($N=150$)
| LaTeX Macro | Value | Source File | Description |
| :--- | :--- | :--- | :--- |
| `\TestOtsuDiceMean` | `0.4859` | `results/stage5_test_metrics.csv` | Global Otsu Mean DSC on TEST split |
| `\TestOtsuPrecMean` | `0.4257` | `results/stage5_test_metrics.csv` | Global Otsu Mean Precision on TEST split |
| `\TestOtsuRecMean` | `0.8817` | `results/stage5_test_metrics.csv` | Global Otsu Mean Recall on TEST split |
| `\TestMultiOtsuDiceMean` | `0.5811` | `results/stage5_test_metrics.csv` | Multi-Otsu (3 Classes) Mean DSC on TEST split |
| `\TestMultiOtsuPVal` | `$5.36 \times 10^{-7}$` | `results/stage5_test_metrics.csv` | Wilcoxon signed-rank p-value vs. Global Otsu |
| `\TestAdaptiveDiceMean` | `0.2838` | `results/stage5_test_metrics.csv` | Adaptive Local Gaussian Mean DSC on TEST split |
| `\TestAdaptivePVal` | `$5.85 \times 10^{-13}$` | `results/stage5_test_metrics.csv` | Wilcoxon signed-rank p-value vs. Global Otsu |
| `\TestKMeansThreeDiceMean` | `0.5815` | `results/stage5_test_metrics.csv` | Selected K-Means ($K=3$) Mean DSC on TEST split |
| `\TestKMeansThreeDiceMedian` | `0.6492` | `results/stage5_test_metrics.csv` | Selected K-Means ($K=3$) Median DSC on TEST split |
| `\TestKMeansThreeIouMean` | `0.4461` | `results/stage5_test_metrics.csv` | Selected K-Means ($K=3$) Mean IoU on TEST split |
| `\TestKMeansThreePrecMean` | `0.6449` | `results/stage5_test_metrics.csv` | Selected K-Means ($K=3$) Mean Precision on TEST split |
| `\TestKMeansThreeRecMean` | `0.6802` | `results/stage5_test_metrics.csv` | Selected K-Means ($K=3$) Mean Recall on TEST split |
| `\TestKMeansThreePVal` | `$7.94 \times 10^{-7}$` | `results/stage5_test_metrics.csv` | Wilcoxon signed-rank p-value vs. Global Otsu |

### 3.3. Failure Analysis Stratification
| LaTeX Macro | Value | Source File | Description |
| :--- | :--- | :--- | :--- |
| `\FailSizeSmallDiceMean` | `0.4034` | `results/failure_analysis_size.csv` | Mean DSC for small lesions ($<1000$ pixels, $N=60$) |
| `\FailSizeSmallPrecMean` | `0.3383` | `results/failure_analysis_size.csv` | Mean Precision for small lesions |
| `\FailSizeMediumDiceMean` | `0.7049` | `results/failure_analysis_size.csv` | Mean DSC for medium lesions ($1000-3000$ pixels, $N=79$) |
| `\FailSizeLargeDiceMean` | `0.6672` | `results/failure_analysis_size.csv` | Mean DSC for large lesions ($>3000$ pixels, $N=11$) |
| `\FailPosInferiorDiceMean` | `0.4227` | `results/failure_analysis_position.csv` | Mean DSC for inferior slices ($z < 55$, $N=23$) |
| `\FailPosMidDiceMean` | `0.5971` | `results/failure_analysis_position.csv` | Mean DSC for mid-axial slices ($55 \le z \le 95$, $N=73$) |
| `\FailPosSuperiorDiceMean` | `0.6281` | `results/failure_analysis_position.csv` | Mean DSC for superior slices ($z > 95$, $N=54$) |

### 3.4. Quantitative Radiomic Morphology Descriptors
| LaTeX Macro | Value | Source File | Description |
| :--- | :--- | :--- | :--- |
| `\MorphAreaMae` | `967.41` | `results/morphology_summary.csv` | Whole-tumor area Mean Absolute Error ($mm^2$) |
| `\MorphAreaMape` | `168.2%` | `results/morphology_summary.csv` | Whole-tumor area Mean Absolute Percentage Error |
| `\MorphPerimeterMae` | `105.41` | `results/morphology_summary.csv` | Whole-tumor perimeter Mean Absolute Error ($mm$) |
| `\MorphCircularityMae` | `0.18` | `results/morphology_summary.csv` | Whole-tumor circularity Mean Absolute Error |
| `\MorphEccentricityMae` | `0.11` | `results/morphology_summary.csv` | Whole-tumor eccentricity Mean Absolute Error |
| `\MorphEccentricityMape` | `17.1%` | `results/morphology_summary.csv` | Whole-tumor eccentricity Mean Absolute Percentage Error |
| `\MorphEccentricityPearsonR` | `0.6100` | `results/morphology_summary.csv` | Pearson correlation coefficient for lesion eccentricity |

### 3.5. Robustness to Imaging Perturbations
| LaTeX Macro | Value | Source File | Description |
| :--- | :--- | :--- | :--- |
| `\RobCleanDiceMean` | `0.5815` | `results/robustness_summary.csv` | Baseline uncorrupted Mean DSC |
| `\RobNoiseMaxDiceMean` | `0.5815` | `results/robustness_summary.csv` | Mean DSC under severe Gaussian noise ($\sigma = 0.10$) |
| `\RobBlurMaxDiceMean` | `0.6124` | `results/robustness_summary.csv` | Mean DSC under spatial Gaussian blur ($\sigma = 2.0$) |
| `\RobGammaLowDiceMean` | `0.5426` | `results/robustness_summary.csv` | Mean DSC under compressed gamma contrast ($\gamma = 0.6$) |
| `\RobShiftHighDiceMean` | `0.5848` | `results/robustness_summary.csv` | Mean DSC under positive brightness shift ($\Delta = +0.10$) |

---

## 4. Pipeline Execution Scripts

1. `src/pipeline.py`: Core end-to-end DIP pipeline wrapper supporting patient loading, slice slicing, preprocessing, skull stripping, and thresholding.
2. `src/segmentation_methods.py`: Pure classical segmentation algorithm implementations (Global Otsu, Multi-Otsu, Adaptive Local Gaussian, K-Means).
3. `src/tumor_segmentation.py`: Classical morphological post-processing (`morphological_tumor_cleanup`) and region properties analysis.
4. `run_stage5_evaluation.py`: Master evaluation script executing the 6 segmentation methods across the 200 slices and calculating Wilcoxon hypothesis test p-values.
5. `src/compute_extended_results.py`: Computes extended experiments on TEST partition: failure stratification, multi-modality benchmarking, geometric morphology descriptors, and perturbation robustness curves.
6. `src/make_paper_figures.py`: Re-renders all 6 publication figures at 300 dpi with white backgrounds and sans-serif fonts in `Mid_Sem_Report/figures/`.
7. `src/generate_latex_numbers.py`: Exports all numerical results to `Mid_Sem_Report/numbers.tex` and auto-generates the 4 LaTeX table files.
