#!/usr/bin/env python3
"""
ECE501 Digital Image Processing Project
Brain MRI Tumor Segmentation and Quantitative Analysis Using Classical Image Processing

Stage 2: Classical MRI Preprocessing & Quantitative Analysis Script (Audit & Fix Refactored)

Author: DIP Project Team
"""

import os
import sys
import numpy as np

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

from src.loader import load_nifti_volume
from src.preprocessing import clip_percentiles, normalize_min_max, extract_axial_slice, find_best_slice
from src.filtering import apply_gaussian_filter, apply_median_filter
from src.enhancement import apply_histogram_equalization, apply_clahe, compute_image_metrics
from src.visualization import plot_preprocessing_comparison, plot_histogram_comparison
from src.utils import ensure_dir


def main():
    print("=" * 75)
    print(" ECE501 DIP Project: Stage 2 - Classical MRI Preprocessing & Analysis")
    print("=" * 75)

    # 1. Define Paths & Ensure Output Directory
    flair_path = os.path.join(PROJECT_ROOT, "BraTS20_Training_001_flair.nii")
    seg_path = os.path.join(PROJECT_ROOT, "BraTS20_Training_001_seg.nii")
    results_dir = ensure_dir(os.path.join(PROJECT_ROOT, "results"))

    # 2. Load Volume and Extract Tumor Slice 67
    print("\n[Step 1] Loading normalized FLAIR slice (Slice 67)...")
    flair_vol, _ = load_nifti_volume(flair_path)
    seg_vol, _ = load_nifti_volume(seg_path)

    # Normalize FLAIR volume
    clipped_flair = clip_percentiles(flair_vol, p_low=0.5, p_high=99.5)
    flair_norm_vol = normalize_min_max(clipped_flair)

    # Find peak slice (Slice 67)
    peak_slice_idx, _ = find_best_slice(seg_vol)
    original_slice = extract_axial_slice(flair_norm_vol, peak_slice_idx)
    mask_slice = extract_axial_slice(seg_vol, peak_slice_idx)
    brain_mask = original_slice > 0

    print(f" Extracted Slice Index : {peak_slice_idx}")
    print(f" Slice Spatial Shape   : {original_slice.shape}")
    print(f" Non-zero Brain Voxels : {np.count_nonzero(brain_mask):,}")

    # 3. Apply Filtering Operations
    print("\n[Step 2] Applying Spatial Filters...")
    gaussian_img = apply_gaussian_filter(original_slice, sigma=1.0)
    gaussian_img[~brain_mask] = 0.0

    median_img = apply_median_filter(original_slice, size=3)
    median_img[~brain_mask] = 0.0

    print(" Applied Gaussian Filter (sigma = 1.0)")
    print(" Applied Median Filter (kernel size = 3)")

    # 4. Apply Mask-Aware Contrast Enhancement
    print("\n[Step 3] Applying Mask-Aware Contrast Enhancement...")
    hist_eq_img = apply_histogram_equalization(original_slice, mask=brain_mask)
    clahe_img = apply_clahe(original_slice, clip_limit=0.03, kernel_size=(8, 8), mask=brain_mask)

    print(" Applied Mask-Aware Global Histogram Equalization")
    print(" Applied Mask-Aware CLAHE (clip_limit = 0.03, tile_grid = 8x8)")

    # Group images into dict
    images_dict = {
        "Original": original_slice,
        "Gaussian": gaussian_img,
        "Median": median_img,
        "HistEq": hist_eq_img,
        "CLAHE": clahe_img
    }

    # 5. Compute Quantitative Metrics strictly over brain mask
    print("\n[Step 4] Computing Quantitative Image Statistics over Brain Mask...")
    metrics_dict = {}
    for name, img in images_dict.items():
        metrics_dict[name] = compute_image_metrics(img, mask=brain_mask, gt_seg_slice=mask_slice)

    # Print Quantitative Table
    header_str = f"{'Method':<12} | {'Mean':<8} | {'Std Dev':<8} | {'Entropy':<8} | {'Edge Strength':<14} | {'Tumor-vs-Normal Contrast':<24}"
    print("-" * len(header_str))
    print(header_str)
    print("-" * len(header_str))
    for name, met in metrics_dict.items():
        print(f"{name:<12} | {met['mean']:<8.4f} | {met['std']:<8.4f} | {met['entropy']:<8.4f} | {met['mean_gradient']:<14.4f} | {met['tumor_vs_normal_contrast']:<24.4f}")
    print("-" * len(header_str))

    # 6. Save Visualization Figures
    print("\n[Step 5] Generating and Saving Comparison Figures to results/...")
    comp_fig_path = os.path.join(results_dir, f"preprocessing_comparison_slice_{peak_slice_idx}.png")
    hist_fig_path = os.path.join(results_dir, f"histogram_comparison_slice_{peak_slice_idx}.png")

    plot_preprocessing_comparison(images_dict, metrics_dict, peak_slice_idx, save_path=comp_fig_path)
    plot_histogram_comparison(images_dict, peak_slice_idx, brain_mask=brain_mask, save_path=hist_fig_path)

    # 7. Write Metrics Summary Text File
    summary_txt_path = os.path.join(results_dir, "stage2_metrics_summary.txt")
    with open(summary_txt_path, "w") as f:
        f.write("STAGE 2 PREPROCESSING QUANTITATIVE METRICS SUMMARY\n")
        f.write("=" * 80 + "\n")
        f.write(f"Analyzed Volume : BraTS20_Training_001_flair.nii\n")
        f.write(f"Axial Slice     : {peak_slice_idx}\n")
        f.write("Metrics computed strictly inside the non-zero brain mask.\n")
        f.write("=" * 80 + "\n\n")
        f.write(header_str + "\n")
        f.write("-" * len(header_str) + "\n")
        for name, met in metrics_dict.items():
            f.write(f"{name:<12} | {met['mean']:<8.4f} | {met['std']:<8.4f} | {met['entropy']:<8.4f} | {met['mean_gradient']:<14.4f} | {met['tumor_vs_normal_contrast']:<24.4f}\n")
        f.write("-" * len(header_str) + "\n")

    print(f"[INFO] Saved metrics summary to: {summary_txt_path}")

    # 8. Create Markdown Summary Document in results/stage2_summary.md
    summary_md_path = os.path.join(results_dir, "stage2_summary.md")
    with open(summary_md_path, "w") as f:
        f.write(f"# Stage 2: Classical MRI Preprocessing & Analysis Summary (Audit Refactored)\n\n")
        f.write(f"## 1. Implemented Methods\n")
        f.write(f"- **Spatial Smoothing Filters**:\n")
        f.write(r"  - **Gaussian Filter ($\sigma=1.0$)**: Linear spatial convolution filter for high-frequency noise suppression." + "\n")
        f.write(r"  - **Median Filter ($k=3$)**: Non-linear rank-order filter for speckle noise reduction while preserving sharp tissue boundaries." + "\n")
        f.write(r"  - **Mask-Aware Global Histogram Equalization**: Spreads out intensity density function over the $[0, 1]$ spectrum within the brain tissue region only." + "\n")
        f.write(r"  - **Mask-Aware CLAHE ($\text{clip\_limit}=0.03$, tile grid $= 8\times8$)**: Contextual adaptive histogram equalization with contrast limiting to prevent noise amplification." + "\n\n")

        f.write(r"## 2. Quantitative Results (Axial Slice " + str(peak_slice_idx) + r", Evaluated Inside Brain Mask)" + "\n\n")
        f.write(r"| Method | Mean ($\mu$) | Std Dev ($\sigma$) | Shannon Entropy (bits) | Edge Strength (MeanGrad) | Tumor-vs-Normal Contrast |" + "\n")
        f.write(f"| :--- | :---: | :---: | :---: | :---: | :---: |\n")
        for name, met in metrics_dict.items():
            f.write(f"| **{name}** | `{met['mean']:.4f}` | `{met['std']:.4f}` | `{met['entropy']:.4f}` | `{met['mean_gradient']:.4f}` | `{met['tumor_vs_normal_contrast']:.4f}` |\n")

        f.write(f"\n## 3. Visual & Quantitative Observations\n\n")
        f.write(f"1. **Filtering Comparison**:\n")
        f.write(f"   - **Gaussian Filter** reduces noise variance ($\\sigma = {metrics_dict['Gaussian']['std']:.4f}$ vs `{metrics_dict['Original']['std']:.4f}`), but noticeably blurs edges, dropping edge strength from `{metrics_dict['Original']['mean_gradient']:.4f}` to `{metrics_dict['Gaussian']['mean_gradient']:.4f}`.\n")
        f.write(f"   - **Median Filter** removes salt-and-pepper noise while preserving edge strength better (`{metrics_dict['Median']['mean_gradient']:.4f}` vs Gaussian `{metrics_dict['Gaussian']['mean_gradient']:.4f}`) and preserving tumor-to-normal contrast (`{metrics_dict['Median']['tumor_vs_normal_contrast']:.4f}`).\n\n")
        f.write(f"2. **Contrast Enhancement Comparison**:\n")
        f.write(f"   - **Global Histogram Equalization** drastically boosts overall brightness and global variance ($\\sigma = {metrics_dict['HistEq']['std']:.4f}$), but over-saturates white matter, creating unnatural contrast gradients across healthy brain parenchyma.\n")
        f.write(f"   - **CLAHE** does *not* substantially change global standard deviation ($\\sigma = {metrics_dict['CLAHE']['std']:.4f}$ vs original `{metrics_dict['Original']['std']:.4f}`). Rather, its measurable advantage is in **information entropy (`{metrics_dict['CLAHE']['entropy']:.4f}` vs `{metrics_dict['Original']['entropy']:.4f}` bits)** and **local edge definition / gradient magnitude (`{metrics_dict['CLAHE']['mean_gradient']:.4f}` vs `{metrics_dict['Original']['mean_gradient']:.4f}`)**, which reveals subtle intra-tumoral heterogeneity without blowing out global brightness.\n\n")

        f.write(f"## 4. Recommended Preprocessing Pipeline for Stage 3 & 4\n\n")
        f.write(r"**Recommended Pipeline: Median Filtering ($k=3$) + CLAHE ($\text{clip\_limit}=0.03$)**" + "\n")
        f.write(f"- Median filtering suppresses high-frequency speckle noise without eroding fine boundary margins.\n")
        f.write(f"- Mask-aware CLAHE maximizes local entropy and boundary gradients while keeping zero-padded background perfectly clean.\n\n")

        f.write(f"## 5. Generated Artifacts\n")
        f.write(f"- `results/preprocessing_comparison_slice_{peak_slice_idx}.png` (5-panel comparison figure)\n")
        f.write(f"- `results/histogram_comparison_slice_{peak_slice_idx}.png` (Intensity distribution plot over brain tissue)\n")
        f.write(f"- `results/stage2_metrics_summary.txt` (Text metrics table)\n")
        f.write(f"- `results/stage2_summary.md` (Markdown summary report)\n")

    print(f"[INFO] Saved Stage 2 summary to: {summary_md_path}")

    print("\n" + "=" * 75)
    print(" Stage 2 Classical MRI Preprocessing Completed Successfully!")
    print(f" Results available in: {results_dir}")
    print("=" * 75)


if __name__ == "__main__":
    main()
