#!/usr/bin/env python3
"""
ECE501 Digital Image Processing Project
Brain MRI Tumor Segmentation and Quantitative Analysis Using Classical Image Processing

Stage 4: Baseline Brain Tumor Segmentation & Quantitative Evaluation Script
Refactored to use modular pipeline (src.pipeline & src.metrics)

Author: DIP Project Team
"""

import os
import sys
import csv
import numpy as np
import matplotlib.pyplot as plt

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

from src.pipeline import run_pipeline, load_config
from src.visualization import plot_stage4_baseline_segmentation, build_evaluation_overlay_rgb
from src.utils import ensure_dir


def main():
    print("=" * 75)
    print(" ECE501 DIP Project: Stage 4 - Baseline Brain Tumor Segmentation")
    print("=" * 75)

    cfg = load_config()
    patient_id = cfg["data"]["default_patient"]
    slice_idx = cfg["data"]["default_slice"]
    modality = cfg["data"]["default_modality"]

    stage4_dir = ensure_dir(os.path.join(PROJECT_ROOT, "results", "stage4"))

    # Execute modular pipeline
    print(f"\n[Step 1] Running pipeline for {patient_id}, Slice {slice_idx} ({modality})...")
    res = run_pipeline(patient_id=patient_id, slice_idx=slice_idx, modality=modality, cfg=cfg)

    metrics = res["metrics"]
    otsu_thresh = res["otsu_thresh"]
    skull_stripped_flair = res["skull_stripped_slice"]
    final_brain_mask = res["brain_mask"]
    initial_candidate_mask = res["candidate_mask"]
    cleaned_tumor_mask = res["final_mask"]
    ground_truth_mask = res["gt_mask"]

    print(f" Loaded Slice Index            : {slice_idx}")
    print(f" Skull-Stripped Brain Voxels   : {np.count_nonzero(skull_stripped_flair):,}")
    print(f" Ground-Truth Tumor Voxels      : {metrics['gt_area_px']:,}")
    print(f" Brain ROI Otsu Threshold Value : {otsu_thresh:.4f}")
    print(f" Predicted Tumor Area           : {metrics['pred_area_px']:,} pixels")
    print(f" Area Difference               : {metrics['area_diff_px']:,} pixels ({metrics['area_error_percent']:+.2f}%)")
    print(f" True Positives (TP)           : {metrics['tp']:,} pixels")
    print(f" False Positives (FP)          : {metrics['fp']:,} pixels")
    print(f" False Negatives (FN)          : {metrics['fn']:,} pixels")
    print(f" Sørensen-Dice Coefficient     : {metrics['dice']:.4f}")
    print(f" Jaccard IoU Index             : {metrics['iou']:.4f}")

    # Save Individual Image Panels
    print("\n[Step 2] Saving Individual Result Images to results/stage4/...")
    plt.imsave(os.path.join(stage4_dir, "skull_stripped_flair.png"), skull_stripped_flair, cmap='gray')
    plt.imsave(os.path.join(stage4_dir, "initial_tumor_mask.png"), initial_candidate_mask, cmap='magma')
    plt.imsave(os.path.join(stage4_dir, "cleaned_tumor_mask.png"), cleaned_tumor_mask, cmap='spring')
    plt.imsave(os.path.join(stage4_dir, "ground_truth_mask.png"), ground_truth_mask, cmap='YlOrRd')

    tp_map = np.logical_and(cleaned_tumor_mask, ground_truth_mask)
    fp_map = np.logical_and(cleaned_tumor_mask, ~ground_truth_mask)
    fn_map = np.logical_and(~cleaned_tumor_mask, ground_truth_mask)

    overlay_rgb = build_evaluation_overlay_rgb(skull_stripped_flair, tp_map, fp_map, fn_map)
    plt.imsave(os.path.join(stage4_dir, "final_tumor_comparison.png"), overlay_rgb)

    # Save 2x3 Grid Visualization
    img_dict = {
        "skull_stripped": skull_stripped_flair,
        "brain_mask": final_brain_mask,
        "initial_candidate": initial_candidate_mask,
        "cleaned_mask": cleaned_tumor_mask,
        "ground_truth": ground_truth_mask
    }
    metrics_display = {
        "dice": metrics["dice"],
        "iou": metrics["iou"],
        "tp_count": metrics["tp"],
        "fp_count": metrics["fp"],
        "fn_count": metrics["fn"],
        "tp_map": tp_map,
        "fp_map": fp_map,
        "fn_map": fn_map
    }
    grid_fig_path = os.path.join(stage4_dir, "stage4_baseline_2x3_grid.png")
    plot_stage4_baseline_segmentation(img_dict, metrics_display, slice_idx, otsu_thresh, save_path=grid_fig_path)

    # Save CSV and Text Reports
    csv_path = os.path.join(stage4_dir, "stage4_metrics.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Patient", "Slice", "Otsu_Threshold", "Pred_Area_px", "GT_Area_px", "Area_Diff_px", "Dice", "IoU", "Precision", "Recall", "TP", "FP", "FN"])
        writer.writerow([patient_id, slice_idx, otsu_thresh, metrics["pred_area_px"], metrics["gt_area_px"], metrics["area_diff_px"], metrics["dice"], metrics["iou"], metrics["precision"], metrics["recall"], metrics["tp"], metrics["fp"], metrics["fn"]])

    txt_path = os.path.join(stage4_dir, "stage4_metrics_summary.txt")
    with open(txt_path, "w") as f:
        f.write("STAGE 4 BASELINE TUMOR SEGMENTATION NUMERICAL METRICS\n")
        f.write("=" * 60 + "\n")
        f.write(f"Patient ID               : {patient_id}\n")
        f.write(f"Axial Slice Number       : {slice_idx}\n")
        f.write(f"Voxel Spacing (dx, dy)   : {res['voxel_spacing'][:2]} mm\n")
        f.write(f"Brain ROI Otsu Threshold : {otsu_thresh:.4f}\n")
        f.write(f"Predicted Tumor Area     : {metrics['pred_area_px']:,} pixels ({metrics.get('pred_area_mm2', 'N/A')} mm²)\n")
        f.write(f"Ground-Truth Tumor Area  : {metrics['gt_area_px']:,} pixels ({metrics.get('gt_area_mm2', 'N/A')} mm²)\n")
        f.write(f"Area Difference          : {metrics['area_diff_px']:,} pixels ({metrics['area_error_percent']:+.2f}%)\n")
        f.write(f"True Positives (TP)      : {metrics['tp']:,} pixels\n")
        f.write(f"False Positives (FP)     : {metrics['fp']:,} pixels\n")
        f.write(f"False Negatives (FN)     : {metrics['fn']:,} pixels\n")
        f.write(f"Sørensen-Dice Coefficient: {metrics['dice']:.4f}\n")
        f.write(f"Jaccard IoU Index        : {metrics['iou']:.4f}\n")
        f.write(f"Precision                : {metrics['precision']:.4f}\n")
        f.write(f"Recall                   : {metrics['recall']:.4f}\n")

    # Update Markdown Summary Report
    md_path = os.path.join(stage4_dir, "stage4_summary.md")
    with open(md_path, "w") as f:
        f.write("# Stage 4: Baseline Brain Tumor Segmentation Summary (Audited)\n\n")
        f.write("## 1. Overview & Pipeline Description\n")
        f.write("Stage 4 implements a baseline classical threshold-based segmentation workflow:\n")
        f.write("1. **Brain ROI Masking**: All operations are strictly constrained to the Stage 3 brain mask (`skull_stripped_flair`). Non-brain voxels are zeroed.\n")
        f.write(f"2. **Otsu Candidate Thresholding**: Calculated global Otsu threshold (`{otsu_thresh:.4f}`) on non-zero brain voxels to extract hyperintense candidate regions.\n")
        f.write("3. **Morphological Cleanup**: Applied morphological opening ($r=2$) to sever isolated noise spikes, followed by closing ($r=2$) to connect adjacent candidate regions.\n")
        f.write("4. **Connected Component Filtering**: Filtered components with area $< 50$ pixels, preserving main candidate regions.\n")
        f.write("5. **Ground-Truth Evaluation**: Evaluated whole-tumor mask (`seg > 0`) against predictions.\n\n")

        f.write("## 2. Quantitative Results\n")
        f.write("| Metric | Numerical Value |\n")
        f.write("| :--- | :---: |\n")
        f.write(f"| **Patient ID** | `{patient_id}` |\n")
        f.write(f"| **Axial Slice Number** | `{slice_idx}` |\n")
        f.write(f"| **Voxel Resolution** | `{res['voxel_spacing'][:2]} mm` |\n")
        f.write(f"| **Brain ROI Threshold ($T_{{Otsu}}$)** | `{otsu_thresh:.4f}` |\n")
        f.write(f"| **Predicted Tumor Area** | `{metrics['pred_area_px']:,}` pixels ({metrics.get('pred_area_mm2', 'N/A')} mm²) |\n")
        f.write(f"| **Ground-Truth Tumor Area** | `{metrics['gt_area_px']:,}` pixels ({metrics.get('gt_area_mm2', 'N/A')} mm²) |\n")
        f.write(f"| **Area Difference** | `{metrics['area_diff_px']:,}` pixels (`{metrics['area_error_percent']:+.2f}%`) |\n")
        f.write(f"| **True Positives (TP)** | `{metrics['tp']:,}` pixels |\n")
        f.write(f"| **False Positives (FP)** | `{metrics['fp']:,}` pixels |\n")
        f.write(f"| **False Negatives (FN)** | `{metrics['fn']:,}` pixels |\n")
        f.write(f"| **Sørensen–Dice Coefficient** | **`{metrics['dice']:.4f}`** |\n")
        f.write(f"| **Jaccard IoU Index** | **`{metrics['iou']:.4f}`** |\n")
        f.write(f"| **Precision** | `{metrics['precision']:.4f}` |\n")
        f.write(f"| **Recall** | `{metrics['recall']:.4f}` |\n\n")

        f.write("## 3. Discussion & Observations\n")
        f.write("- **Strengths**:\n")
        f.write("  - The baseline Otsu thresholding method successfully isolates the hyperintense core of the FLAIR tumor region.\n")
        f.write(f"  - Achieved a baseline **Dice score of {metrics['dice']:.4f}** and **IoU of {metrics['iou']:.4f}** using simple classical thresholding.\n")
        f.write("- **Limitations of Simple Global Otsu Baseline**:\n")
        f.write("  - Global Otsu thresholding tends to capture hyperintense white matter regions alongside tumor tissue, producing some false positives.\n")
        f.write("  - Peritumoral edema (ED) has intermediate intensity levels that fall slightly below global Otsu thresholding, leading to false negatives.\n")
        f.write("  - These limitations motivate the adaptive thresholding, region growing, and multi-modal classical DIP techniques in Stage 5.\n\n")

        f.write("## 4. Generated Output Files in `results/stage4/`\n")
        f.write("- `skull_stripped_flair.png`\n")
        f.write("- `initial_tumor_mask.png`\n")
        f.write("- `cleaned_tumor_mask.png`\n")
        f.write("- `ground_truth_mask.png`\n")
        f.write("- `final_tumor_comparison.png`\n")
        f.write("- `stage4_baseline_2x3_grid.png`\n")
        f.write("- `stage4_metrics.csv`\n")
        f.write("- `stage4_metrics_summary.txt`\n")

    # Print Required Summary Block to Console
    print("\n" + "=" * 75)
    print("Stage 4 completed.")
    print("-" * 35)
    print(f"Slice: {slice_idx}")
    print(f"Threshold: {otsu_thresh:.4f}")
    print(f"Predicted tumor area: {metrics['pred_area_px']} px")
    print(f"Ground-truth tumor area: {metrics['gt_area_px']} px")
    print(f"Dice: {metrics['dice']:.4f}")
    print(f"IoU: {metrics['iou']:.4f}")
    print("-" * 35)
    print("\n[Pipeline Details]")
    print("1. Thresholding Method: Otsu thresholding computed over non-zero brain ROI voxels.")
    print("2. Morphological Operations: Binary opening (disk r=2) to remove isolated noise spikes, followed by binary closing (disk r=2) to connect tumor sub-regions.")
    print("3. Connected Component Analysis: Region labeling (`skimage.measure.label`), area computation, and removal of components smaller than 50 pixels.")
    print("=" * 75 + "\n")


if __name__ == "__main__":
    main()
